$domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
$PDC = ($domainObj.PdcRoleOwner).Name
$SearchString = "LDAP://"
$SearchString += $PDC + "/"
$DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"
$SearchString += $DistinguishedName
$Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)
$objDomain = New-Object System.DirectoryServices.DirectoryEntry
$Searcher.SearchRoot = $objDomain
$Searcher.filter="serviceprincipalname=*"
$Result = $Searcher.FindAll()
$ErrorActionPreference = 'silentlycontinue'
Foreach($obj in $Result)
{
        Foreach($prop in $obj.Properties)
        {
                $easyclients = $prop.dnshostname
                $hostname = $($prop.serviceprincipalname -match ".corp.com")
                #write-host "hostname:  $hostname"
                $hostname = %{$data = $_.split("/"); Write-Output $($data[0])} -erroraction 'silentlycontinue'
                if($hostname -contains ":")
                {
                        #write-host "$hostname contains a colon"
                        $hostname = %{$data = $_.split(":"); Write-Output $($data[0])}
                        #write-host "hostname after split:  $hostname"
                        #$prop.serviceprincipalname
                }
                 $prop.serviceprincipalname
                 Test-NetConnection $easyclients -ErrorAction 'silentlyContinue'
                 Test-NetConnection $hostname -erroraction 'silentlycontinue'
        }
        Write-Host "--------------------------------------------------------"
}